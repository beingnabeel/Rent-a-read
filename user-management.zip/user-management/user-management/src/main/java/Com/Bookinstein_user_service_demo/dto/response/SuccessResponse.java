package Com.Bookinstein_user_service_demo.dto.response;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SuccessResponse {
      private String message;
      private Object body;

}

