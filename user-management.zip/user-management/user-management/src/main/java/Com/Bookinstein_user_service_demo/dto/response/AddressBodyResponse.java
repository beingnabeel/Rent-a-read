package Com.Bookinstein_user_service_demo.dto.response;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AddressBodyResponse
{
    private String id;
    private String userId;
//    private String profileId;
//    private AddressType addressType;
    private String house;
    private String street;
    private String landmark;
    private String city;
    private String state;
    private String country;
    private Long pincode;
    private boolean IsDefault;
    private boolean isDeleted;
}
