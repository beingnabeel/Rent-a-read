package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.dto.request.*;
import Com.Bookinstein_user_service_demo.dto.response.*;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.entities.UserProfile;
import Com.Bookinstein_user_service_demo.enums.Role;
import Com.Bookinstein_user_service_demo.enums.UserStatus;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

public interface UserRegistrationService
{
  //List<UserResponse> getAllUsers();
  PageResponse<UserResponse> getAllUsers(UserStatus status, Integer pageNumber, Integer pageSize, String searchKey);

    UserResponse getUserById(String uid) ;
  SuccessResponse updateUser(String uid, UpdateBody updateBody, HttpServletRequest request);
  void deleteUser(String uid);

  //List<UserResponse> getAllUserProfiles();
 // SuccessResponse updateUserProfiles(int id);

    SuccessResponse addUserProfile(UserProfilesBody userProfilesBody, HttpServletRequest request);

    SuccessResponse updateUserProfiles(String id, UserProfilesBody userProfilesBody, HttpServletRequest request);

    SuccessResponse getUserProfileById(String id);

    List<UserAndAllProfilesResponse> getAllUserProfiles();

    String uploadImage(MultipartFile image, HttpServletRequest request) throws IOException;

//    public String preSignedUrl(String fileName);

    String deleteImage(HttpServletRequest request ) throws IOException;

    UserProfile getUserProfileByUserIdAndProfileId(String userId, String profileId);

    User updateUserAndProfile(String userId, String profileId, UpdateBody updateBody);

    List<UserProfileResponse> getUserProfilesByUserId(String userId, boolean isDefault);

//  String updatePassword(String userId, UpdatePasswordRequest passwordUpdateDto);


  UserProfile getUserProfileByEmail(String email);

 // List<UserProfile> searchUserProfiles(String firstName, String lastName, String status, String role);
  List<User> searchUsers(String firstName, String lastName);

  @NotNull(message = "Role is required") String getUserRole(String id);

  SuccessResponse addUserByAdmin(@Valid AddUserByAdminRequestBody addUserByAdminRequestBody);

   // SuccessResponse addUserByAdmin(AddUserByAdminRequestBody addUserByAdminRequestBody);

    String updatePassword(String token, UpdatePasswordRequest request);

   PageResponse<UserAndProfile> getAllUserAndProfiles( Integer pageNumber, Integer pageSize, String searchKey, Role roleName);

   // List<UserProfileLimitedInfo> getAllUserAndProfiles(String searchKey);

    List<User> getAllUsersForExcelSheet();

    void saveUsers(MultipartFile file) throws IOException;

    OtpVerificationResponse sendOtp(SendOtpMobileRequest request);

    OtpVerificationResponse verifyOtp(VerifyOtpMobileRequest request);

    List<User> getUsersByStatus(UserStatus status);

    List<NewlyOnboaredUserAndProfileResponse> getUsersByTimeframe(UserStatus status, LocalDateTime startTime, LocalDateTime endTime);

    List<User> getUsersByRole(Role roleName);


    //List<UserAndAllProfilesResponse> getAllUserWithProfile(Role role, String searchKey, @NotEmpty String profileId);


    //  List<UserProfileLimitedInfo> getAllUserAndProfiles(Role role, String searchKey);

    // List<UserWithProfile> getAllUserWithProfile(Role role, String searchKey, @NotEmpty List<Long> profileIds);


}
