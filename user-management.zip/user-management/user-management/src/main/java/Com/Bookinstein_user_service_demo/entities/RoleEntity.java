package Com.Bookinstein_user_service_demo.entities;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;
import java.util.Optional;


@Document(collection = "roles")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class RoleEntity {
    @Id
    private String id;
    private String roleName;
    private Instant CreatedAt;
    private Instant UpdatedAt;

}