package Com.Bookinstein_user_service_demo.Client;

import Com.Bookinstein_user_service_demo.dto.response.SchoolAddress;
import Com.Bookinstein_user_service_demo.exception.SchoolServiceUnavailableException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class SchoolClient {

    private final String SCHOOL_SERVICE_URL = "http://127.0.0.1:4002/api/v1/schools-service/schools";
    private final RestTemplate restTemplate;

    @Autowired
    public SchoolClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public SchoolAddress getSchool(String schoolId) {
        try {
            String url = SCHOOL_SERVICE_URL + "/" + schoolId;
            return restTemplate.getForObject(url, SchoolAddress.class);
        } catch (Exception e) {
            throw new SchoolServiceUnavailableException("Error fetching school details for ID: " + schoolId, e);
        }
    }
}