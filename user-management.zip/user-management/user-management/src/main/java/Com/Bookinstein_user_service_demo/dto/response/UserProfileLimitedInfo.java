package Com.Bookinstein_user_service_demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
public class UserProfileLimitedInfo
{
    private String userId;
    private String profileId;
    private String emailFirstNameLastName;
    private List<String> roles;
}
