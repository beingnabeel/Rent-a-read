package Com.Bookinstein_user_service_demo.controller;

import Com.Bookinstein_user_service_demo.dto.request.AddRole;
import Com.Bookinstein_user_service_demo.dto.request.PermissionRequest;
import Com.Bookinstein_user_service_demo.dto.request.RolePermissionRequest;
import Com.Bookinstein_user_service_demo.entities.Permission;
import Com.Bookinstein_user_service_demo.entities.RoleEntity;
import Com.Bookinstein_user_service_demo.exception.DuplicatePermissionException;
import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import Com.Bookinstein_user_service_demo.service.RoleService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@SecurityRequirement(name = "Authorization")
@RequestMapping("/roles")
public class RoleController {

    @Autowired
    private RoleService roleService;

    @Autowired
    private UserRepo userRepository;

        @PostMapping
        public RoleEntity createRole(@RequestBody AddRole role) {
            return roleService.createRole(role);
        }

    @PostMapping("assignRoleToUser/{roleId}/users/{userId}")   // i think this api is not valid
    public void assignRoleToUser(@PathVariable String userId, @PathVariable String roleId) {
        roleService.assignRoleToUser(userId, roleId);
    }

        @GetMapping
        public List<RoleEntity> getAllRoles() {
            return roleService.getAllRoles();
        }

        @GetMapping("/{id}")
        public RoleEntity getRoleById(@PathVariable String id) {
            return roleService.getRoleById(id);
        }

        @PutMapping("/{id}")
        public RoleEntity updateRole(@PathVariable String id, @RequestBody AddRole role) {
            return roleService.updateRole(id, role);
        }

        @DeleteMapping("/{id}")
        public void deleteRole(@PathVariable String id) {
            roleService.deleteRole(id);
        }

    @GetMapping("/users/{userId}/roles")
    public ResponseEntity<List<RoleEntity>> getRolesByUserId(@PathVariable String userId) {
        try {
            List<RoleEntity> roles = roleService.getRolesByUserId(userId);
            return ResponseEntity.ok(roles);
        } catch (UserNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
    }