package Com.Bookinstein_user_service_demo.repository;

import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.entities.UserProfile;
import Com.Bookinstein_user_service_demo.enums.Role;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;


public interface UserProfileRepo extends MongoRepository<UserProfile, String>{
   // List<UserProfile> findByUId(String id);
    // Optional<UserProfile> findByEmail(String email);
    List<UserProfile> findByUserId(String userId);
    Optional<UserProfile> findByUserIdAndProfileId(String userId, String profileId);

    Optional<UserProfile> findByUserIdAndIsDefault(String userId, boolean b);

   // Optional<UserProfile> findByEmail(String email);

    List<UserProfile> findByStatus(String status);

    Optional<UserProfile> findByEmail(String email);

    List<UserProfile> findAllByUserId(String userId);

 @Query("{ 'role': ?0, '$or': [ { 'firstName': { $regex: ?1, $options: 'i' } }, { 'lastName': { $regex: ?1, $options: 'i' } } ] }")
 List<UserProfile> findByRoleAndSearchKey(String role, String searchKey);

 List<UserProfile> findByUserIdIn(List<String> userIds);

    Optional<UserProfile> findByProfileIdAndUserId(String userId, String profileId);

    Optional<UserProfile> findByProfileIdAndDefaultAddressId(String profileId, String defaultAddressId);

    Optional<UserProfile> findByUserIdAndDefaultAddressId(String userId, String addressId);

    Optional<UserProfile> findByDefaultAddressId(String defaultAddressId);

   // List<UserWithProfile> getAllUserWithProfile(Role role, String searchKey, String profileIds);

   // List<UserAndAllProfilesResponse> getAllUserWithProfile(Role role, String searchKey, String profileId);

    // List<UserProfile> findByRole(String roles);
    Page<UserProfile> findByCreatedAtBetween(LocalDateTime startTime, LocalDateTime endTime, Pageable pageable);

    Page<UserProfile> searchByFirstNameOrLastName(String searchKey, Pageable pageable);


    @Query("{ $and: [ { 'role': ?0 }, { $or: [ { 'firstName': { $regex: ?1, $options: 'i' } }, { 'lastName': { $regex: ?1, $options: 'i' } } ] } ] }")
    List<UserProfile> searchByRoleORName(Role role, String searchKey);

    List<UserProfile> findAllByUserIdAndIsDefault(String id, boolean isDefault);

    Optional<UserProfile> findByProfileIdAndIsDefault(String profileId, boolean isDefault);
}
