package Com.Bookinstein_user_service_demo.repository;


import Com.Bookinstein_user_service_demo.entities.RolePermission;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface RolePermissionRepository extends MongoRepository<RolePermission, String> {

    List<RolePermission> findByRoleIdIn(List<String> roleIds);
    List<RolePermission> findByRoleId(String roleId);

    void deleteByRoleId(String roleId);
}
