package Com.Bookinstein_user_service_demo.dto.response;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class UserAddresses {
    private PageResponse<UserAddress> userAddresses;
    private SchoolAddress schoolAddress;
}
