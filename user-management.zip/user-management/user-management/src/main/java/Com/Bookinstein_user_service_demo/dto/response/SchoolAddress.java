package Com.Bookinstein_user_service_demo.dto.response;

import Com.Bookinstein_user_service_demo.enums.AddressType;
import Com.Bookinstein_user_service_demo.enums.WeekDay;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SchoolAddress {
    @Schema(description = "Id of school", required = true)
    private Long id;
    @Schema(description = "Name of school", required = true)
    private String name;
    @Schema(description = "Branch of school", required = true)
    private String branch;
    @Schema(description = "Address of school", required = true)
    private String address;
    @Schema(description = "Pincode of school", required = true)
    private Long pincode;
    @Schema(description = "Day of delivery", required = true)
    private WeekDay weekDay;
    private String landmark;
    private String city;
    private String state;
    private String country;
    private AddressType addressType = AddressType.SCHOOL;
    private boolean isDefault;
}
