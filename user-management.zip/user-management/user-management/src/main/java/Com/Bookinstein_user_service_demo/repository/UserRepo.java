package Com.Bookinstein_user_service_demo.repository;


import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.enums.Role;
import Com.Bookinstein_user_service_demo.enums.UserStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepo extends MongoRepository<User, String>{

    boolean existsById(String userId);
    boolean existsByEmail(String email);
    boolean existsByPhoneNo(String phoneNumber);
    Optional<User> findByEmail(String email);

    List<User> findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(String firstName, String lastName);

    List<User> findByLastNameContainingIgnoreCase(String lastName);

    List<User> findByFirstNameContainingIgnoreCase(String firstName);
    Optional<User> findByResetToken(String resetToken);

    void deleteAllByTokenExpiryBefore(LocalDateTime now);


//    Page<User> findByRoles(Role role, Pageable pageable);

    User findByPhoneNo(String mobileNumber);

    List<User> findByStatus(UserStatus status);

   // List<User> findByCreatedAtBetween(LocalDateTime startTime, LocalDateTime endTime);

    List<User> findUsersWithProfilesByCreatedAtBetween(LocalDateTime startTime, LocalDateTime endTime);

    @Query("{ 'role': ?0, $or: [ { 'firstName': { $regex: ?1, $options: 'i' } }, { 'lastName': { $regex: ?1, $options: 'i' } }, { 'email': { $regex: ?1, $options: 'i' } } ] }")
    List<User> findByRoleAndSearchKey(Role role, String searchKey);

    List<User> findByFirstNameContainingIgnoreCaseAndLastNameContainingIgnoreCase(String firstName, String lastName);

    Page<User> findAllByEmailContainingIgnoreCaseOrPhoneNoContainingIgnoreCase(String searchKey, String searchKey1, Pageable pageable);

    Page<User> findAllByStatus(UserStatus status, Pageable pageable);

    List<User> findUsersWithProfilesByCreatedAtBetweenAndStatus(LocalDateTime startTime, LocalDateTime endTime, UserStatus status);

    List<User> findByIdIn(List<String> userIds);
}
