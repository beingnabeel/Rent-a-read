package Com.Bookinstein_user_service_demo.service;

import io.jsonwebtoken.ExpiredJwtException;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;


@Service
@RequiredArgsConstructor
public class TokenCacheService {
    private final JwtService jwtService;

    private static final String ACCESS_TOKEN_PREFIX = "loginToken_";
    private static final String REFRESH_TOKEN_PREFIX = "refreshToken_";

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    public void storeTokens(String userId, String loginToken, String refreshToken) {

        redisTemplate.opsForValue().set(ACCESS_TOKEN_PREFIX+userId,loginToken);

        redisTemplate.opsForValue().set(REFRESH_TOKEN_PREFIX+userId,refreshToken);
    }

    public void invalidateTokens( String userId) {
        redisTemplate.delete(ACCESS_TOKEN_PREFIX + userId);
        redisTemplate.delete(REFRESH_TOKEN_PREFIX + userId);
    }

    public boolean isValidToken(String token) {
        System.out.println("token "+token);
        String userId = jwtService.extractUserId(token);
        String storedAccessToken = (String) redisTemplate.opsForValue().get(ACCESS_TOKEN_PREFIX + userId);
        String storedRefreshToken = (String) redisTemplate.opsForValue().get(REFRESH_TOKEN_PREFIX + userId);

        if (storedAccessToken == null && storedRefreshToken == null) {
            return false;
        }
        System.out.println("Stored access token "+storedAccessToken);
        System.out.println("Stored refresh token "+storedRefreshToken);

        boolean isValidAccessToken = token.equals(storedAccessToken);
        boolean isValidRefreshToken = token.equals(storedRefreshToken);

        return isValidAccessToken || isValidRefreshToken;
    }
    public boolean isValidRefreshToken(String token) {
        String userId = jwtService.extractUserId(token);
        return token.equals(redisTemplate.opsForValue().get(REFRESH_TOKEN_PREFIX + userId));
    }

    public String getRefreshToken(String userId) {
            return (String) redisTemplate.opsForValue().get(REFRESH_TOKEN_PREFIX + userId);
    }
}