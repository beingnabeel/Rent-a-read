package Com.Bookinstein_user_service_demo.exception;

public class RequestMathodNotSupported extends RuntimeException {
    public RequestMathodNotSupported(String message) {
        super("Request url not found");
    }
}
