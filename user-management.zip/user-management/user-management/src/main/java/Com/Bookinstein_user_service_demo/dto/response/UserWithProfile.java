package Com.Bookinstein_user_service_demo.dto.response;

import Com.Bookinstein_user_service_demo.enums.Role;

public class UserWithProfile
{
    private String id;
    private Long profileId;
    private Role role;
    private String email;
    private Long mobile;
    private String firstName;
    private String lastName;
    private Long schoolId;
    private String classAndSection;
    private String profilePictureUrl;
}
