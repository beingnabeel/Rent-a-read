package Com.Bookinstein_user_service_demo.repository;

import Com.Bookinstein_user_service_demo.entities.UserRole;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface UserRoleRepository extends MongoRepository<UserRole, String> {
    List<UserRole> findByUserId(String userId);

    List<String> findRolesByUserId(String id);

    void deleteByRoleId(String roleId);

    List<UserRole> findByUserIdIn(List<String> userIds);

    List<UserRole> findByRoleId(String id);
}
