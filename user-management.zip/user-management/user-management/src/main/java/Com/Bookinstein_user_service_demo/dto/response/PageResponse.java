package Com.Bookinstein_user_service_demo.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PageResponse <T>{

    List<T> content;
    @Schema(description = "Current page number")
    int pageNumber;
    @Schema(description = "Size of the page or limit")
    int pageSize;
    @Schema(description = "Total number of pages")
    int totalPages;
    @Schema(description = "Total number of elements")
    long totalElements;
    @Schema(description = "First page or not")
    boolean first;
    @Schema(description = "Last page or not")
    boolean last;
    @Schema(description = "Number of records in current page")
    int numberOfElements;

}
