package Com.Bookinstein_user_service_demo.config;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "twilio")
@Data
@NoArgsConstructor
public class MobileOtpTwilioConfig {
    private  String ACCOUNT_SID = "AC304d2a662effd347e67b6cae3762d2fb";
    private  String AUTH_TOKEN = "a54d46a634b2fef651016dcdc7195b4d";
    private  String FROM_PHONE_NUMBER = "+13185368202";

    @Override
    public String toString() {
        return "MobileOtpTwilioConfig{" +
                "ACCOUNT_SID='" + ACCOUNT_SID + '\'' +
                ", AUTH_TOKEN='" + AUTH_TOKEN + '\'' +
                ", FROM_PHONE_NUMBER='" + FROM_PHONE_NUMBER + '\'' +
                '}';
    }
}
