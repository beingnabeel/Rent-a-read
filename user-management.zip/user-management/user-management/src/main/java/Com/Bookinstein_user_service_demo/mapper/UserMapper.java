package Com.Bookinstein_user_service_demo.mapper;

import Com.Bookinstein_user_service_demo.dto.request.AddUserByAdminRequestBody;
import Com.Bookinstein_user_service_demo.dto.request.UpdateBody;
import Com.Bookinstein_user_service_demo.dto.request.UserRequestBody;
import Com.Bookinstein_user_service_demo.dto.response.UserResponse;
import Com.Bookinstein_user_service_demo.entities.User;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

@Mapper
public interface UserMapper {
    User userRequestBodyToUser(UserRequestBody userRequestBody);

    UserResponse userToUserResponse(User user);

    void map(@MappingTarget User user, UpdateBody updateBody);

    User addAdminUserBodyToUser(AddUserByAdminRequestBody addUserByAdminRequestBody);
}
