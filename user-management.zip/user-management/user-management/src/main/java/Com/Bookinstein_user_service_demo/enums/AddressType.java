package Com.Bookinstein_user_service_demo.enums;

public enum AddressType
{
    HOME,
    SCHOOL
}
