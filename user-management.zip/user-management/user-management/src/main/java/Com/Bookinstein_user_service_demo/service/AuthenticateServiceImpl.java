package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.Client.SchoolClient;
import Com.Bookinstein_user_service_demo.dto.request.LoginRequest;
import Com.Bookinstein_user_service_demo.dto.request.UserRequestBody;
import Com.Bookinstein_user_service_demo.dto.response.LoginResponse;
import Com.Bookinstein_user_service_demo.dto.response.SuccessResponse;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.entities.UserProfile;
import Com.Bookinstein_user_service_demo.entities.UserRole;
import Com.Bookinstein_user_service_demo.enums.UserProfileStatus;
import Com.Bookinstein_user_service_demo.enums.UserStatus;
import Com.Bookinstein_user_service_demo.exception.*;
import Com.Bookinstein_user_service_demo.mapper.UserAuthenticationMapper;
import Com.Bookinstein_user_service_demo.repository.RoleRepository;
import Com.Bookinstein_user_service_demo.repository.UserProfileRepo;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import Com.Bookinstein_user_service_demo.repository.UserRoleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.Period;

@Service
@Slf4j
@RequiredArgsConstructor
public class AuthenticateServiceImpl implements AuthenticationService {

    private final UserRepo userRepo;
    private final UserProfileRepo userProfileRepo;
    private final UserAuthenticationMapper userAuthenticationMapper;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtService jwtService;
    private final TokenCacheService tokenCacheService;
    private final SchoolClient schoolClient;
    private final UserRoleRepository userRoleRepository;
    private final RoleRepository roleRepo;

    @Transactional
    @Override
    public SuccessResponse createUser(UserRequestBody userRequestBody)  {
        if (userRepo.existsByEmail(userRequestBody.getEmail().toLowerCase())) {
            throw new UserAlreadyFoundException("User Already registred " + userRequestBody.getEmail());
        }
        if (userRepo.existsByPhoneNo(userRequestBody.getPhoneNo())) {
            throw new UserAlreadyFoundException("User Already registred " + userRequestBody.getPhoneNo());
        }

        User user = new User();
        user.setFirstName(userRequestBody.getFirstName());
        user.setLastName(userRequestBody.getLastName());
        user.setEmail(userRequestBody.getEmail().toLowerCase());
        user.setPhoneNo(userRequestBody.getPhoneNo());
        user.setPassword(passwordEncoder.encode(userRequestBody.getPassword()));
        user.setDateOfBirth(userRequestBody.getDateOfBirth());
        user.setStatus(UserStatus.ACTIVE);
        user.setIsDeleted(false);
        try {
            userRepo.save(user);
            log.info("User inserted => {}", user);

            UserProfile userProfile = new UserProfile();
            userProfile.setFirstName(userRequestBody.getFirstName());
            userProfile.setLastName(userRequestBody.getLastName());
            userProfile.setUserId(user.getId());
            userProfile.setEmail(user.getEmail());
            userProfile.setDateOfBirth(userRequestBody.getDateOfBirth());
            userProfile.setAge(findAgeFromDob(user.getDateOfBirth()));
            userProfile.setDefault(true);
            userProfile.setStatus(UserProfileStatus.ACTIVE);
                if (userRequestBody.getSchoolId() != null) {
                    try {
                    userProfile.setSchoolId(userRequestBody.getSchoolId());
                    userProfile.setClassAndSection(userRequestBody.getClassAndSection());
                    userProfile.setSchoolName(schoolClient.getSchool(userRequestBody.getSchoolId()).getName());

            } catch (SchoolServiceUnavailableException e) {
                log.error("Failed to fetch school details: {}", e.getMessage());
                throw e; // Rollback transaction
            }
        }

        userProfileRepo.save(userProfile);

        UserRole userRole = new UserRole();
        userRole.setUserId(user.getId());
        userRole.setRoleId("677e63a9ef55850738443a88");
        userRole.setCreatedAt(java.time.Instant.now());
        userRole.setUpdatedAt(java.time.Instant.now());
        userRoleRepository.save(userRole);
        return SuccessResponse.builder().message("User Created Successfully").body(user).build();
        } catch (Exception e) {
            log.error("Error occurred while creating user: {}", e.getMessage());
            throw e; // Rollback transaction
        }
    }
    private Integer findAgeFromDob(LocalDate dateOfBirth) {
        if (dateOfBirth == null) {
            return null;
        }
        return Period.between(dateOfBirth, LocalDate.now()).getYears(); // Calculate age in years
    }

    public LoginResponse authenticate(LoginRequest input) {
        User user = userRepo.findByEmail(input.getEmail())
                .orElseThrow(() -> new UserNotFoundException("Wrong Email"));

        if (user.getStatus() == UserStatus.INACTIVE) {
            throw new UnauthorizedException("Your account is inactive. Please contact support.");
        }

        if (!passwordEncoder.matches(input.getPassword(), user.getPassword())) {
            throw new InvalidPasswordException("Wrong Password");
        }

        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(input.getEmail(), input.getPassword())
        );

        String accessToken = jwtService.generateAccessToken(user);
        String refreshToken = jwtService.generateRefreshToken(user);

        tokenCacheService.storeTokens(user.getId(), accessToken, refreshToken);

        LoginResponse loginResponse = new LoginResponse();
        loginResponse.setToken(accessToken);
        loginResponse.setExpiresIn(jwtService.getTokenExpiryTime());
        loginResponse.setRefreshToken(refreshToken);

        return loginResponse;
    }

}
