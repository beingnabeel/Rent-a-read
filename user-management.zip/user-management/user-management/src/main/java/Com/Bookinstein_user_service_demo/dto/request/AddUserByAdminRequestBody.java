package Com.Bookinstein_user_service_demo.dto.request;

import Com.Bookinstein_user_service_demo.enums.Role;
import Com.Bookinstein_user_service_demo.enums.UserProfileStatus;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class AddUserByAdminRequestBody
{
    @Email
    @NotNull
    private String email;
    @NotBlank
    private String password;
    @Pattern(regexp="(^$|[0-9]{10})",message="{invalid mobile")
    private String mobile;
    @NotBlank
    private String firstName;
    @NotBlank
    private String lastName;
    @NotNull(message = "accept the date like 2024-05-30")
    private LocalDate dateOfBirth;
    private String schoolId;
    private String classAndSection;
    private UserProfileStatus status = UserProfileStatus.ACTIVE;
}
