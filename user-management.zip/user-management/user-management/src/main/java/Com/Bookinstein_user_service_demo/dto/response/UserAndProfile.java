package Com.Bookinstein_user_service_demo.dto.response;

import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.enums.AddressType;
import Com.Bookinstein_user_service_demo.enums.UserProfileStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserAndProfile {
        private User user;
        private String id;
        private String userId;
        private String firstName;
        private String lastName;
        private boolean isDefault;
        private String schoolId;
        private String schoolName;
        private String classAndSection;
        private String profilePictureUrl;
        private UserProfileStatus status;
        private AddressType defaultAddressType;
        private String defaultAddressId;
        private Instant createdAt;
        private String createdBy;
        private Instant updatedAt;
        private String updatedBy;

}

