package Com.Bookinstein_user_service_demo.dto.request;

import Com.Bookinstein_user_service_demo.enums.Role;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
public class CurrentUser {
    private final String userId;
    private final String profileId;
    private final Role role;
    private final String schoolId;
}
