package Com.Bookinstein_user_service_demo.controller;

import Com.Bookinstein_user_service_demo.dto.request.DefaultAddressBody;
import Com.Bookinstein_user_service_demo.dto.request.UserAddressBody;
import Com.Bookinstein_user_service_demo.dto.response.*;
import Com.Bookinstein_user_service_demo.service.UserAddressService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/users")
@RequiredArgsConstructor
@Validated
@SecurityRequirement(name = "Authorization")
public class UserAddressController {

    private final UserAddressService userAddressService;

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN')) and hasAuthority('Write_Data')")
    @PostMapping("/{id}/profiles/{profileId}/addresses")
    @ResponseStatus(HttpStatus.CREATED)
    public SuccessResponse addUserAddress(
            @PathVariable(required = false) String id,
            @PathVariable(required = false) String profileId,
            @Valid
            @RequestBody UserAddressBody userAddressBody,
            HttpServletRequest request) {
        return userAddressService.addUserAddress(id, profileId, userAddressBody, request);
    }

    @PostMapping("/addresses")
    @ResponseStatus(HttpStatus.CREATED)
    public SuccessResponse addUserAddressByUserId(
            @Valid
            @RequestBody UserAddressBody userAddressBody,
            HttpServletRequest request) {
        return userAddressService.addUserAddressByUserId(userAddressBody, request);
    }
//        @GetMapping(value = {"/{id}/profiles/{profileId}/addresses", "/addresses"})
//        public UserAddresses getUserAddresses(
//        @PathVariable(required = false) String id,
//        @PathVariable(required = false) String profileId,
//        @Positive @RequestParam(required = false, defaultValue = "1") Integer pageNumber,
//        @Positive @RequestParam(required = false, defaultValue = "10") Integer pageSize) {
//            return userAddressService.getUserAddresses(id, profileId, pageNumber, pageSize);
//}

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN') and hasAuthority('Read_Data')")
    @GetMapping(value = {"/{id}/profiles/{profileId}/addresses/default"})
    public DefaultAddress getDefaultUserAddresses(
            @PathVariable String id,
            @PathVariable String profileId) {
        return userAddressService.getDefaultUserAddresses(id, profileId);
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN') and hasAuthority('Read_Data')")
    @GetMapping(value = {"/pincodes/{id}"})
    public List<PostalResponse> getPostOffice(
            @Positive
            @PathVariable(value = "id") Long pincode) {
        return userAddressService.getPostOffice(pincode);
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN') and hasAuthority('Write_Data')")
    @PutMapping(value = {"/{id}/profiles/{profileId}/addresses/default"})
    public SuccessResponse updateDefaultUserAddresses(
            @PathVariable String id,
            @PathVariable String profileId,
            @Valid @RequestBody DefaultAddressBody defaultAddressBody) {
        return userAddressService.updateDefaultUserAddresses(id, profileId, defaultAddressBody);
    }

//    @DeleteMapping(value = {"/{profileId}/addresses/{addressId}", "/addresses/{addressId}"})
//    @ResponseStatus(HttpStatus.NO_CONTENT)
//    public void deleteUserAddress(
//            @PathVariable(required = false) String profileId,
//            @PathVariable("addressId") String defaultAddressId) {
//        userAddressService.deleteUserAddress(profileId, defaultAddressId);
//    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN') and hasAuthority('Write_Data')")
    @PatchMapping("/delete/addresses/{addressId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteUserAddress(
            @PathVariable String addressId,
            HttpServletRequest request) {
        userAddressService.deleteUserAddress(addressId, request);
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN') and hasAuthority('Write_Data')")
    @PatchMapping("/addressess/{addressId}")
    public SuccessAddressResponse updateUserAddress(
            @PathVariable String addressId,
            @Valid
            @RequestBody UserAddressBody userAddressBody,
            HttpServletRequest request) {
        return userAddressService.updateUserAddress(addressId, userAddressBody, request);
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN') and hasAuthority('Read_Data')")
    @GetMapping("/{userId}/addresses")
    public ResponseEntity<List<AddressBodyResponse>> getUserAddresses(@PathVariable String userId) {
        List<AddressBodyResponse> addressList = userAddressService.getAllUserAddresses(userId);
        return ResponseEntity.ok(addressList);
    }

}
