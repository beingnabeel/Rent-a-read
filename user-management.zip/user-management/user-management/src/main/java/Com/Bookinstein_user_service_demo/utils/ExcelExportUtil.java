package Com.Bookinstein_user_service_demo.utils;

import Com.Bookinstein_user_service_demo.entities.User;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import java.util.List;

public class ExcelExportUtil {

    private XSSFWorkbook workbook;
    private XSSFSheet sheet;
    private List<User> listUsers;

    public ExcelExportUtil(List<User> listUsers) {
        this.listUsers = listUsers;
        this.workbook = new XSSFWorkbook();
        this.sheet = workbook.createSheet("Users");
    }

    private void writeHeaderRow() {
        Row headerRow = sheet.createRow(0);

        CellStyle headerStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 14);
        headerStyle.setFont(font);

        String[] headers = {"ID", "Name", "Email", "Phone No", "Role"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            cell.setCellStyle(headerStyle);
        }
    }

    private void writeDataRows() {
        if (listUsers == null || listUsers.isEmpty()) {
            System.out.println("No data available for Excel export.");
            return;
        }

        int rowCount = 1;

        CellStyle dataStyle = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setFontHeightInPoints((short) 12);
        dataStyle.setFont(font);

        for (User user : listUsers) {
            Row row = sheet.createRow(rowCount++);

            row.createCell(0).setCellValue(user.getId());
            row.createCell(1).setCellValue(user.getFirstName() + " " + user.getLastName());
            row.createCell(2).setCellValue(user.getEmail());
            row.createCell(3).setCellValue(user.getPhoneNo());
           // row.createCell(4).setCellValue(user.getRoleId().name());
        }

        for (int i = 0; i < 5; i++) {
            sheet.autoSizeColumn(i);
        }
    }

    public void export(HttpServletResponse response) throws IOException {
        writeHeaderRow();
        writeDataRows();

        try (ServletOutputStream outputStream = response.getOutputStream()) {
            workbook.write(outputStream);
            outputStream.flush();
        } finally {
            workbook.close();
        }
    }
}

