package Com.Bookinstein_user_service_demo.service;
import Com.Bookinstein_user_service_demo.dto.response.SuccessPasswordResponse;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Random;

@Service
public class EmailVerificationService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private JavaMailSender mailSender;


    public SuccessPasswordResponse sendOtp(String email) {
        Optional<User> userOptional = userRepo.findByEmail(email);
        if (!userOptional.isPresent()) {
            throw new IllegalStateException("User not found.");
        }

        User user = userOptional.get();

        if (user.isEmailVerified()) {
            throw new IllegalStateException("Email is already verified.");
        }


        String otp = generateOtp();
        LocalDateTime expiry = LocalDateTime.now().plusMinutes(10); // OTP valid for 10 minutes

        user.setOtp(otp);
        user.setOtpExpiry(expiry);
        userRepo.save(user);


        sendOtpEmail(email, otp);

        return new SuccessPasswordResponse("OTP sent to your email.");
    }


    public String verifyOtp(String email, String otp) {
        Optional<User> userOptional = userRepo.findByEmail(email);
        if (!userOptional.isPresent()) {
            throw new IllegalStateException("User not found.");
        }

        User user = userOptional.get();

        if (user.isEmailVerified()) {
            throw new IllegalStateException("Email is already verified.");
        }

        if (user.getOtp() == null || !user.getOtp().equals(otp)) {
            throw new IllegalStateException("Invalid OTP.");
        }

        if (user.getOtpExpiry().isBefore(LocalDateTime.now())) {
            throw new IllegalStateException("OTP has expired.");
        }


        user.setEmailVerified(true);
        user.setOtp(null);
        user.setOtpExpiry(null);
        userRepo.save(user);

        return "Email verified successfully.";
    }


    private String generateOtp() {
        Random random = new Random();
        return String.format("%06d", random.nextInt(999999));
    }

    // Send OTP to the user's email
    private void sendOtpEmail(String email, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Your OTP Code");
        message.setText("Your OTP is: " + otp + ". It is valid for 10 minutes.");
        message.setFrom("swetakumari633564@gmail.com");

        mailSender.send(message);
    }
}