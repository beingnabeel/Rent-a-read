package Com.Bookinstein_user_service_demo.dto.response;

import Com.Bookinstein_user_service_demo.enums.AddressType;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class NewlyOnboardedProfile {
    private String id;
    private String userId;
    private String firstName;
    private String lastName;
    private LocalDate dob;
    private Integer age;
    private boolean isDefault;
    private String schoolId;
    private String schoolName;
    private String adminComment;
  //  private UserProfileStatus status;
    private AddressType defaultAddressType;
    private String defaultAddressId;
    private Instant createdAt;
//    private String createdBy;
    private Instant updatedAt;

//    private String updatedBy;
}
