package Com.Bookinstein_user_service_demo.repository;


import Com.Bookinstein_user_service_demo.entities.Permission;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface PermissionRepository extends MongoRepository<Permission, String> {
    boolean existsByPermissionName(String name);
    List<Permission> findByIdIn(List<String> permissionIds);
}

