package Com.Bookinstein_user_service_demo.entities;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

import java.time.Instant;

@Setter
@Getter
@Document(collection = "usersAddress")
public class UserAddressEntity {
    @Id
    private String id;
    @Field(targetType = FieldType.OBJECT_ID)
    private String userId;
    private String house;
    private String landmark;
    private String street;
    @NotBlank(message = "{mandatory pincode}")
    @Pattern(regexp = "\\d{6}", message = "Pincode must be exactly 6 digits.")
    private String pincode;
    private String city;
    private String state;
    private String country;
    @CreatedDate
    private Instant createdAt;
    @CreatedBy
    private String createdBy;
    @LastModifiedDate
    private Instant updatedAt;
    @LastModifiedBy
    private String updatedBy;
    private boolean isDefault;
    private Boolean isDeleted;
}
