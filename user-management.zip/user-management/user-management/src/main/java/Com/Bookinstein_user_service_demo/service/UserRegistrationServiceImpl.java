package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.Client.SchoolClient;
import Com.Bookinstein_user_service_demo.config.MobileOtpTwilioConfig;
import Com.Bookinstein_user_service_demo.dto.request.*;
import Com.Bookinstein_user_service_demo.dto.response.*;
import Com.Bookinstein_user_service_demo.entities.RoleEntity;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.entities.UserProfile;
import Com.Bookinstein_user_service_demo.entities.UserRole;
import Com.Bookinstein_user_service_demo.enums.Role;
import Com.Bookinstein_user_service_demo.enums.UserProfileStatus;
import Com.Bookinstein_user_service_demo.enums.UserStatus;
import Com.Bookinstein_user_service_demo.exception.*;
import Com.Bookinstein_user_service_demo.mapper.UserMapper;
import Com.Bookinstein_user_service_demo.mapper.UserProfileMapper;
import Com.Bookinstein_user_service_demo.repository.RoleRepository;
import Com.Bookinstein_user_service_demo.repository.UserProfileRepo;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import Com.Bookinstein_user_service_demo.repository.UserRoleRepository;
import Com.Bookinstein_user_service_demo.utils.APIFeatures;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UserRegistrationServiceImpl implements UserRegistrationService {

    private final UserRepo userRepo;
    private final UserProfileRepo userProfileRepo;
    private final UserMapper userMapper;
    private final UserProfileMapper userProfileMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AmazonS3 amazonS3;
    private final SchoolClient schoolClient;
    private final UserRoleRepository userRoleRepo;
    private final RoleRepository roleRepo;

    @Autowired
    private MongoTemplate mongoTemplate;


    public UserRegistrationServiceImpl(UserRepo userRepo,
                                       UserProfileRepo userProfileRepo, PasswordEncoder passwordEncoder, JwtService jwtService, AmazonS3 amazonS3, SchoolClient schoolClient, UserRoleRepository userRoleRepo, RoleRepository roleRepo
    ) {
        this.userRepo = userRepo;
        this.userProfileRepo = userProfileRepo;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.amazonS3 = amazonS3;
        this.schoolClient = schoolClient;
        this.userRoleRepo = userRoleRepo;
        this.roleRepo = roleRepo;
        this.userMapper = Mappers.getMapper(UserMapper.class);
        this.userProfileMapper = Mappers.getMapper(UserProfileMapper.class);
    }

//    @Override
//    public List<UserResponse> getAllUsers() {
//        List<User> users = userRepo.findAll();
//        List<UserResponse> userResponses = new ArrayList<>();
//
//        for (User user : users) {
//            UserResponse userResponse = new UserResponse();
//            userResponse.setId(user.getId());
//            userResponse.setFirstName(user.getFirstName());
//            userResponse.setLastName(user.getLastName());
//            userResponse.setEmail(user.getEmail());
//            userResponse.setEmailVerified(user.isEmailVerified());
//            userResponse.setPhoneNo(user.getPhoneNo());
//            userResponse.setPhoneNoVerified(user.isPhoneNoVerified());
//            userResponse.setUserType(user.getUserType());
//            userResponse.setRole(user.getRoles());
//            userResponse.setCreatedAt(user.getCreatedAt());
//            userResponse.setCreatedBy(user.getCreatedBy());
//            userResponse.setUpdatedAt(user.getUpdatedAt());
//            userResponse.setUpdatedBy(user.getUpdatedBy());
//
//            userResponses.add(userResponse);
//        }
//        return userResponses;
//    }
public PageResponse<UserResponse> getAllUsers(UserStatus status, Integer pageNumber, Integer pageSize, String searchKey) {
    Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by(Sort.Direction.ASC, "createdAt"));
    Page<User> userEntityPage;

    Query query = new Query();
    Map<String, String> queryString = new HashMap<>();
    queryString.put("search", searchKey);
    queryString.put("page", pageNumber.toString());
    queryString.put("limit", pageSize.toString());

    APIFeatures apiFeatures = new APIFeatures(query, queryString);
    apiFeatures
            .filter()
            .search()
            .sort()
            .limitFields()
            .paginate();

    if (StringUtils.hasText(searchKey)) {
        List<User> users = mongoTemplate.find(apiFeatures.getQuery(), User.class);
        long totalElements = mongoTemplate.count(apiFeatures.getQuery(), User.class);

        int skip = pageNumber * pageSize;
        List<User> paginatedUsers = users.stream().skip(skip).limit(pageSize).toList();

        List<UserResponse> userResponses = paginatedUsers.stream().map(this::mapToUserResponse).toList();

        return PageResponse.<UserResponse>builder()
                .content(userResponses)
                .pageNumber(pageNumber)
                .pageSize(pageSize)
                .totalPages((int) Math.ceil((double) totalElements / pageSize))
                .totalElements(totalElements)
                .first(pageNumber == 1)
                .last((pageNumber + 1) * pageSize >= totalElements)
                .numberOfElements(userResponses.size())
                .build();
    } else if (UserStatus.ACTIVE.equals(status) || UserStatus.INACTIVE.equals(status)) {
        userEntityPage = userRepo.findAllByStatus(status, pageable);
    } else {
        userEntityPage = userRepo.findAll(pageable);
    }

    List<UserResponse> userResponses = userEntityPage.getContent().stream().map(this::mapToUserResponse).toList();

    return PageResponse.<UserResponse>builder()
            .content(userResponses)
            .pageNumber(userEntityPage.getNumber())
            .pageSize(userEntityPage.getSize())
            .totalPages(userEntityPage.getTotalPages())
            .totalElements(userEntityPage.getTotalElements())
            .first(userEntityPage.isFirst())
            .last(userEntityPage.isLast())
            .numberOfElements(userEntityPage.getNumberOfElements())
            .build();
}

    private UserResponse mapToUserResponse(User user) {
        UserResponse userResponse = new UserResponse();
        userResponse.setId(user.getId());
        userResponse.setFullName(user.getFirstName()+" "+user.getLastName());
        userResponse.setEmail(user.getEmail());
        userResponse.setEmailVerified(user.isEmailVerified());
        userResponse.setPhoneNo(user.getPhoneNo());
        userResponse.setPhoneNoVerified(user.isPhoneNoVerified());
        userResponse.setUserStatus(user.getStatus());
     //   userResponse.setRole(Role.valueOf(user.getRoleId()));
        userResponse.setCreatedAt(user.getCreatedAt());
        userResponse.setCreatedBy(user.getCreatedBy());
        userResponse.setUpdatedAt(user.getUpdatedAt());
        userResponse.setUpdatedBy(user.getUpdatedBy());
        return userResponse;
    }


    @Override
    public UserResponse getUserById(String uid) {
        Optional<User> userOptional = userRepo.findById(uid);
        if (userOptional.isPresent()) {
            User user = userOptional.get();
//            UserResponse userResponse = userMapper.userToUserResponse(user);
            UserResponse userResponse = new UserResponse();
            userResponse.setId(user.getId());
            userResponse.setFullName(user.getFirstName()+" "+user.getLastName());
            userResponse.setEmail(user.getEmail());
            userResponse.setEmailVerified(user.isEmailVerified());
            userResponse.setPhoneNo(user.getPhoneNo());
            userResponse.setPhoneNoVerified(user.isPhoneNoVerified());
            userResponse.setUserStatus(user.getStatus());
           // userResponse.setRole(Role.valueOf(user.getRoleId()));
            userResponse.setCreatedAt(user.getCreatedAt());
            userResponse.setCreatedBy(user.getCreatedBy());
            userResponse.setUpdatedAt(user.getUpdatedAt());
            userResponse.setUpdatedBy(user.getUpdatedBy());

            return userResponse;
        } else {
            throw new UserNotFoundException(uid);
        }
    }

    @Override
//    public SuccessResponse updateUser(String uid, UpdateBody updateBody) {
//        //TODO -- validate user name
//
//        Optional<User> userOptional = userRepo.findById(uid);
//
//        if (userOptional.isPresent()) {
//            User user = userOptional.get();
//           // UserStatus status = user.getStatus();
//           // userMapper.map(user, updateBody);
////            user.setStatus(updateBody.getStatus());
////            user.setEmail(updateBody.getEmail());
//
//            userRepo.save(user);
//            return SuccessResponse.builder().message("User Updated Successfully").body(updateBody).build();  // need to ask what will be body argument.
//        } else {
//            throw new UserNotFoundException("User with id " + uid + " not found");
//        }

    public SuccessResponse updateUser(String uid, UpdateBody updateBody, HttpServletRequest request) {
        try {
            final String authHeader = request.getHeader("Authorization");
            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                throw new UnauthorizedException("Authorization header is missing or invalid");
            }

            final String jwt = authHeader.substring(7);
            String currentUserId = jwtService.extractUserId(jwt);

            if (!currentUserId.equals(uid)) {
                throw new UnauthorizedException("You are not authorized to update this profile");
            }

            Optional<User> userOptional = userRepo.findById(uid);
            if (userOptional.isEmpty()) {
                throw new UserNotFoundException("User with id " + uid + " not found");
            }

            User user = userOptional.get();
            log.debug("User before update: {}", user);
            user.setFirstName(updateBody.getFirstName());
            user.setLastName(updateBody.getLastName());
            user.setDateOfBirth(updateBody.getDateOfBirth());
            user.setPhoneNo(updateBody.getPhoneNo());

            User updatedUser = userRepo.save(user);

            return SuccessResponse.builder()
                    .message("User Updated Successfully")
                    .body(updatedUser)
                    .build();
        } catch (UnauthorizedException e) {
            log.error("Unauthorized access error: {}", e.getMessage());
            throw e;
        } catch (UserNotFoundException e) {
            log.error("User not found error: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("An unexpected error occurred: {}", e.getMessage());
            throw new RuntimeException("An error occurred while updating the user profile");
        }
    }

@Override
public void deleteUser(String uid) {
    User user = userRepo.findById(uid).orElseThrow(() -> new UserNotFoundException("User not found"));
    user.setStatus(UserStatus.INACTIVE);
    user.setIsDeleted(true);
    userRepo.save(user);

    log.info("User with ID {} has been marked as INACTIVE.", uid);
}


    @Override
    public SuccessResponse addUserProfile(UserProfilesBody userProfilesBody, HttpServletRequest request) {
        final String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new IllegalStateException("Invalid Authorization header");
        }
        final String jwt = authHeader.substring(7);
        String currentUserId = jwtService.extractUserId(jwt);
        Optional<User> user = userRepo.findById(currentUserId);
        if (user.isEmpty()) {
            throw new IllegalStateException("User not found with ID: " + currentUserId);
        }
        UserProfile userProfile = new UserProfile();
        userProfile.setFirstName(userProfilesBody.getFirstName());
        userProfile.setLastName(userProfilesBody.getLastName());
        userProfile.setDefault(userProfilesBody.isDefault());
        userProfile.setSchoolId(userProfilesBody.getSchoolId());
        userProfile.setDateOfBirth(userProfilesBody.getDateOfBirth());
        userProfile.setClassAndSection(userProfilesBody.getClassAndSection());
        userProfile.setStatus(userProfilesBody.getStatus());
        userProfile.setAdminComment(userProfilesBody.getAdminComment());
        userProfile.setUserId(user.get().getId());
        userProfile.setEmail(user.get().getEmail());
        userProfile.setPhoneNumber(user.get().getPhoneNo());

        if (userProfile.getDateOfBirth() != null) {
            userProfile.setDateOfBirth(userProfilesBody.getDateOfBirth());
            userProfile.setAge(Period.between(userProfilesBody.getDateOfBirth(), LocalDate.now()).getYears());
        }

        if (userProfilesBody.isDefault()) {
            Optional<UserProfile> defaultUserProfileEntity = userProfileRepo.findByUserIdAndIsDefault(currentUserId, true);
            if (defaultUserProfileEntity.isPresent()) {
                UserProfile defaultEntity = defaultUserProfileEntity.get();
                defaultEntity.setDefault(false);
                userProfileRepo.save(defaultEntity);
            }
        }

        UserProfile savedProfile = userProfileRepo.save(userProfile);

        return SuccessResponse.builder()
                .message("User profile created successfully.")
                .body(savedProfile)
                .build();
    }

    private Integer findAgeFromDob(LocalDate dateOfBirth) {
        if (dateOfBirth == null) {
            return null;
        }
        return Period.between(dateOfBirth, LocalDate.now()).getYears(); // Calculate age in years
    }

//    @Override
//    public SuccessResponse updateUserProfiles(String id, UserProfilesBody userProfilesBody) {
//        Optional<UserProfile> optionalUserProfile = userProfileRepo.findById(id);
//        Optional<User> user = userRepo.findById(userProfilesBody.getUserId());
//        if (optionalUserProfile.isPresent()) {
//            UserProfile userProfile = optionalUserProfile.get();
//
//            userProfile.setFirstName(userProfilesBody.getFirstName());
//            userProfile.setAdminComment(userProfilesBody.getAdminComment());
//            userProfile.setUpdatedAt(userProfile.getUpdatedAt());
////            userProfile.setDateOfBirth(userProfilesBody.getDateOfBirth());
//          //  userProfile.setUserId(user.get().getId());
//            userProfile.setClassAndSection(userProfilesBody.getClassAndSection());
//
//            UserProfile updatedUserprofile = userProfileRepo.save(userProfile);
//
//            return SuccessResponse.builder().message("User Updated Successfully").body(updatedUserprofile).build();
//        } else {
//            throw new UserNotFoundException("User with id " + id + " not found");
//        }
//    }
@Override
public SuccessResponse updateUserProfiles(String id, UserProfilesBody userProfilesBody, HttpServletRequest request) {

    final String authHeader = request.getHeader("Authorization");
    if (authHeader == null || !authHeader.startsWith("Bearer ")) {
        throw new UnauthorizedException("Authorization header is missing or invalid");
    }
    final String jwt = authHeader.substring(7);
    String currentUserId = jwtService.extractUserId(jwt);

    Optional<UserProfile> optionalUserProfile = userProfileRepo.findById(id);
    if (optionalUserProfile.isEmpty()) {
        throw new UserNotFoundException("User profile with id " + id + " not found");
    }
    UserProfile userProfile = optionalUserProfile.get();

    if (!userProfile.getUserId().equals(currentUserId)) {
        throw new UnauthorizedException("You are not authorized to update this profile");
    }

    userProfile.setFirstName(userProfilesBody.getFirstName());
    userProfile.setLastName(userProfilesBody.getLastName());
    userProfile.setDateOfBirth(userProfilesBody.getDateOfBirth());
    userProfile.setAge(Period.between(userProfilesBody.getDateOfBirth(), LocalDate.now()).getYears());
    userProfile.setStatus(userProfile.getStatus());
    userProfile.setAdminComment(userProfilesBody.getAdminComment());
    userProfile.setUpdatedAt(Instant.now());
    userProfile.setProfileImageUrl(userProfilesBody.getProfileImageUrl());
    userProfile.setClassAndSection(userProfilesBody.getClassAndSection());
    UserProfile updatedUserProfile = userProfileRepo.save(userProfile);

    return SuccessResponse.builder()
            .message("User profile updated successfully")
            .body(updatedUserProfile)
            .build();
}

    @Override
    public SuccessResponse getUserProfileById(String id) {

        Optional<UserProfile> optionalUserProfile = userProfileRepo.findById(id);
        if (optionalUserProfile.isPresent()) {
            UserProfile userProfile = optionalUserProfile.get();

            return SuccessResponse.builder()
                    .message("User Profile fetched successfully")
                    .body(userProfile)
                    .build();
        } else {
            throw new UserNotFoundException("User profile with id " + id + " not found");
        }
    }

    @Override
    public List<UserAndAllProfilesResponse> getAllUserProfiles() {

        List<User> users = userRepo.findAll();

        List<UserAndAllProfilesResponse> userAndAllProfilesResponses = new ArrayList<>();

        for (User user : users) {
            UserAndAllProfilesResponse userAndAllProfilesResponse = new UserAndAllProfilesResponse();
            userAndAllProfilesResponse.setUser(user);

            List<UserProfile> userProfileList = userProfileRepo.findByUserId(user.getId()).stream().map(i -> {
                i.setAge(findAgeFromDob(user.getDateOfBirth()));
                return i;
            }).toList();
            userAndAllProfilesResponse.setUserProfiles(userProfileList);
            userAndAllProfilesResponses.add(userAndAllProfilesResponse);
        }
        return userAndAllProfilesResponses;
    }

    @Override
    public List<UserProfileResponse> getUserProfilesByUserId(String userId, boolean isDefault) {

        User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        List<UserProfile> userProfiles = userProfileRepo.findAllByUserIdAndIsDefault(user.getId(),isDefault);

        if (userProfiles.isEmpty()) {
            System.out.println("User Profile is empty");
        }
        List<UserProfileResponse> userProfileResponses = new ArrayList<>();
        for (UserProfile userProfile : userProfiles) {
            UserProfileResponse response = new UserProfileResponse();
            response.setId(userProfile.getProfileId());
            response.setUserId(userProfile.getUserId());
            response.setFullName(userProfile.getFirstName()+" "+userProfile.getLastName());
            response.setEmail(userProfile.getEmail());
            response.setPhoneNumber(user.getPhoneNo());
            response.setAge(findAgeFromDob(user.getDateOfBirth()));
            response.setSchoolId(userProfile.getSchoolId());
            response.setSchoolName(userProfile.getSchoolName());
            response.setStatus(userProfile.getStatus());
            response.setProfileImageUrl(userProfile.getProfileImageUrl());
            response.setDefault(userProfile.isDefault());
            response.setAdminComment(userProfile.getAdminComment());
            response.setClassAndSection(userProfile.getClassAndSection());
            response.setCreatedAt(userProfile.getCreatedAt().toString());
            response.setCreatedBy(userProfile.getCreatedBy());
            response.setDefaultAddressId(userProfile.getDefaultAddressId());
            response.setDefaultAddressType(String.valueOf(userProfile.getDefaultAddressType()));

            userProfileResponses.add(response);
            System.out.println("Response added: " + response);
        }

        return userProfileResponses;
    }

    @Override
    public UserProfile getUserProfileByEmail(String email) {
        return null;
    }

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    @Value("${aws.s3.region}")
    private String region;

    public String uploadImage(MultipartFile image, HttpServletRequest request) {
        final String authHeader = request.getHeader("Authorization");
        final String jwt = authHeader.substring(7);
        String userId = jwtService.extractUserId(jwt);
        if (image == null || image.isEmpty()) {
            throw new ImageUploadException("Image is null or empty!");
        }

        String originalFileName = image.getOriginalFilename();
        if (originalFileName == null || originalFileName.isBlank()) {
            throw new ImageUploadException("Invalid file name!");
        }

        String fileExtension = originalFileName.substring(originalFileName.lastIndexOf("."));
        if (!fileExtension.equals(".jpg") && !fileExtension.equals(".jpeg") && !fileExtension.equals(".png")) {
            throw new ImageUploadException("Invalid file extension! Only JPG, JPEG, and PNG are allowed.");
        }
        String folderName = "sweta";
       // String fileName = folderName + "/"+ UUID.randomUUID().toString() + fileExtension;
        String fileName = folderName + "/" + originalFileName;
        System.out.println(fileName);

        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(image.getSize());
        metadata.setContentType(image.getContentType());

        try {
            PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName, fileName, image.getInputStream(), metadata);
            amazonS3.putObject(putObjectRequest);
//            String imageUrl = "https://s3.amazonaws.com/" + bucketName + "/" + fileName;
            String imageUrl = "https://" + bucketName + ".s3." + region + ".amazonaws.com/" + fileName;
            System.out.println("Uploaded image URL: " + imageUrl);
            saveProfileImage(imageUrl,userId);
             return "Profile Image uploaded successfully";
        } catch (IOException e) {
            throw new ImageUploadException("Error in uploading image to S3", e);
        }
    }

    private void saveProfileImage(String imageUrl,String userId) {
      List<UserProfile> userProfile =  userProfileRepo.findByUserId(userId);
        UserProfile profile = userProfile.get(0);
        profile.setProfileImageUrl(imageUrl);
        userProfileRepo.save(profile);
    }

//    public String preSignedUrl(String fileName) {
//        Date expirationDate = new Date();
//        long time = expirationDate.getTime();
//        int hour = 2;
//        time = time + hour * 60 * 60 * 1000;
//        expirationDate.setTime(time);
//
//        GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, fileName)
//                .withMethod(HttpMethod.GET)
//                .withExpiration(expirationDate);
//        URL url = amazonS3.generatePresignedUrl(generatePresignedUrlRequest);
//
//        return url.toString();
//    }

    public String deleteImage(HttpServletRequest request) {
        final String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new ImageUploadException("Authorization header is missing or invalid!");
        }

        final String jwt = authHeader.substring(7);
        String userId = jwtService.extractUserId(jwt);

        List<UserProfile> userProfile = userProfileRepo.findByUserId(userId);
        if (userProfile.isEmpty()) {
            throw new ImageUploadException("User profile not found for userId: " + userId);
        }

        UserProfile profile = userProfile.get(0);
        String imageUrl = profile.getProfileImageUrl();

        if (imageUrl == null || imageUrl.isEmpty()) {
            throw new ImageUploadException("No profile image URL found for userId: " + userId);
        }

//        String bucketBaseUrl = "https://s3.amazonaws.com/" + bucketName + "/";
        String bucketBaseUrl = "https://" + bucketName + ".s3." + region + ".amazonaws.com/";
        if (!imageUrl.startsWith(bucketBaseUrl)) {
            throw new ImageUploadException("Invalid image URL: Does not match the bucket URL");
        }
        String folderAndFileName = imageUrl.substring(bucketBaseUrl.length());

        try {
            if (!amazonS3.doesObjectExist(bucketName, folderAndFileName)) {
                throw new ImageUploadException("File does not exist in S3: " + folderAndFileName);
            }

            DeleteObjectRequest delObjReq = new DeleteObjectRequest(bucketName, folderAndFileName);
            amazonS3.deleteObject(delObjReq);

            profile.setProfileImageUrl(null);
            userProfileRepo.save(profile);

            return "File deleted successfully: " + folderAndFileName;
        } catch (Exception e) {
            throw new ImageUploadException("Error deleting file from S3: " + e.getMessage(), e);
        }
    }


    // need suggestion
    public UserProfile getUserProfileByUserIdAndProfileId(String userId, String profileId) {
        Optional<UserProfile> userProfile = userProfileRepo.findByUserIdAndProfileId(userId, profileId);

        if (userProfile.isPresent()) {
            return userProfile.get();
        } else {
            throw new UserNotFoundException("User Profile not found with userId: " + userId + " and profileId: " + profileId);
        }
    }

    public User updateUserAndProfile(String userId, String profileId, UpdateBody updateBody) {

        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + userId));

        if (updateBody.getFirstName() != null) {
            user.setFirstName(updateBody.getFirstName());
        }
        if (updateBody.getLastName() != null) {
            user.setLastName(updateBody.getLastName());
        }
        if (updateBody.getPhoneNo() != null) {
            user.setPhoneNo(updateBody.getPhoneNo());
        }
        userRepo.save(user);

        UserProfile userProfile = userProfileRepo.findByUserIdAndProfileId(userId, profileId)
                .orElseThrow(() -> new UserNotFoundException("User profile not found with userId: " + userId + " and profileId: " + profileId));

        if (updateBody.getFirstName() != null) {
            userProfile.setFirstName(updateBody.getFirstName());
        }
        if (updateBody.getLastName() != null) {
            userProfile.setLastName(updateBody.getLastName());
        }
        userProfileRepo.save(userProfile);
        return user;
    }

    public List<User> searchUsers(String firstName, String lastName) {
        log.info("Inside service");
        if (Objects.nonNull(firstName) && Objects.nonNull(lastName)) {
            return userRepo.findByFirstNameContainingIgnoreCaseOrLastNameContainingIgnoreCase(firstName, lastName);
        } else if (Objects.nonNull(lastName)) {
            return userRepo.findByLastNameContainingIgnoreCase(lastName);
        } else if (Objects.nonNull(firstName)) {
            return userRepo.findByFirstNameContainingIgnoreCase(firstName);
        } else {
            return userRepo.findAll();
        }
    }

    @Override
    public @NotNull(message = "Role is required") String getUserRole(String id) {
        User userEntity = userRepo.findById(id).orElse(null);

        if (userEntity != null) {
            return userEntity.getRoleId();
        } else {
            throw new RuntimeException("User not found");
        }
    }

    @Transactional
    @Override
    public SuccessResponse addUserByAdmin(AddUserByAdminRequestBody addUserByAdminRequestBody) {

        if (userRepo.existsByEmail(addUserByAdminRequestBody.getEmail())) {
            throw new UserAlreadyFoundException("Email " + addUserByAdminRequestBody.getEmail() + " already exists");
        }
        if (userRepo.existsByPhoneNo(addUserByAdminRequestBody.getMobile())) {
            throw new UserAlreadyFoundException("Mobile " + addUserByAdminRequestBody.getMobile() + " already exists");
        }
        User user = new User();
        user.setFirstName(addUserByAdminRequestBody.getFirstName());
        user.setLastName(addUserByAdminRequestBody.getLastName());
        user.setEmail(addUserByAdminRequestBody.getEmail().toLowerCase());
        user.setPassword(passwordEncoder.encode(addUserByAdminRequestBody.getPassword()));
        user.setPhoneNo(addUserByAdminRequestBody.getMobile());
        user.setDateOfBirth(addUserByAdminRequestBody.getDateOfBirth());
        user.setStatus(UserStatus.ACTIVE);

        userRepo.save(user);

        UserProfile userProfile = userProfileMapper.addUserByAdminRequestBodyToUserProfile(addUserByAdminRequestBody);
        userProfile.setUserId(user.getId());
        userProfile.setDefault(true);
        userProfile.setAge(findAgeFromDob(user.getDateOfBirth()));
        userProfile.setStatus(UserProfileStatus.ACTIVE);

        if(addUserByAdminRequestBody.getSchoolId() != null) {
            String schoolName = schoolClient.getSchool(addUserByAdminRequestBody.getSchoolId()).getName();
            userProfile.setSchoolId(addUserByAdminRequestBody.getSchoolId());
            userProfile.setClassAndSection(addUserByAdminRequestBody.getClassAndSection());
            userProfile.setSchoolName(schoolName);
        }

        userProfileRepo.save(userProfile);

        UserRole userRole = new UserRole();
        userRole.setUserId(user.getId());
        userRole.setRoleId("677e5d83a524896d4fbfd2f4");
        userRole.setCreatedAt(java.time.Instant.now());
        userRole.setUpdatedAt(java.time.Instant.now());
        userRoleRepo.save(userRole);

        return SuccessResponse.builder()
                .message("User added successfully.").body(user)
                .build();
    }


    public String updatePassword(String token, UpdatePasswordRequest request) {
        if (jwtService.isTokenExpired(token)) {
            throw new ExpiredTokenException("Token is expired");
        }
        String email = jwtService.extractUsername(token);
        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found"));

        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            throw new PasswordMismatchException("Current password is incorrect");
        }

        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new PasswordMismatchException("New password and confirm password do not match");
        }

        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepo.save(user);
        return "Password updated successfully";
    }

//    @Override
//    public PageResponse<UserAndProfile> getAllUserAndProfiles(
//            Integer pageNumber, Integer pageSize, String searchKey) {
//
//        Query query = new Query();
//        Map<String, String> queryString = new HashMap<>();
//        queryString.put("search", searchKey);
//        queryString.put("page", pageNumber.toString());
//        queryString.put("limit", pageSize.toString());
//
//
//       // query.addCriteria(Criteria.where("roles").is(role));
//
//        APIFeatures apiFeatures = new APIFeatures(query, queryString);
//        apiFeatures
//                .filter()
//                .search()
//                .sort()
//                .limitFields()
//                .paginate();
//
//        List<User> users = mongoTemplate.find(apiFeatures.getQuery(), User.class);
//        long totalElements = mongoTemplate.count(apiFeatures.getQuery(), User.class);
//
//        List<String> userIds = users.stream().map(User::getId).collect(Collectors.toList());
//        List<UserProfile> userProfiles = userProfileRepo.findByUserIdIn(userIds);
//
//        List<UserAndProfile> userAndProfiles = new ArrayList<>();
//        for (User user : users) {
//            UserProfile matchedProfile = userProfiles.stream()
//                    .filter(profile -> profile.getUserId().equals(user.getId()))
//                    .findFirst()
//                    .orElse(null);
//
//            UserAndProfile dto = new UserAndProfile();
//            dto.setUser(user);
//
//            if (matchedProfile != null) {
//                dto.setId(matchedProfile.getProfileId());
//                dto.setUserId(matchedProfile.getUserId());
//                dto.setFirstName(matchedProfile.getFirstName());
//                dto.setLastName(matchedProfile.getLastName());
//                dto.setCreatedAt(matchedProfile.getCreatedAt());
//                dto.setSchoolId(matchedProfile.getSchoolId());
//                dto.setSchoolName(matchedProfile.getSchoolName());
//                dto.setDefaultAddressId(matchedProfile.getDefaultAddressId());
//                dto.setDefaultAddressType(matchedProfile.getDefaultAddressType());
//                dto.setClassAndSection(matchedProfile.getClassAndSection());
//                dto.setStatus(UserProfileStatus.ACTIVE);
//                dto.setDefault(matchedProfile.isDefault());
//                dto.setCreatedBy(matchedProfile.getCreatedBy());
//                dto.setUpdatedBy(matchedProfile.getUpdatedBy());
//            }
//
//            userAndProfiles.add(dto);
//        }
//
//        PageResponse<UserAndProfile> response = new PageResponse<>();
//        response.setContent(userAndProfiles);
//        response.setPageNumber(pageNumber);
//        response.setPageSize(pageSize);
//        response.setTotalPages((int) Math.ceil((double) totalElements / pageSize));
//        response.setTotalElements(totalElements);
//        response.setFirst(pageNumber == 1);
//        response.setLast(pageNumber == (int) Math.ceil((double) totalElements / pageSize));
//        response.setNumberOfElements(userAndProfiles.size());
//
//        return response;
//    }
//
@Override
public PageResponse<UserAndProfile> getAllUserAndProfiles(
        Integer pageNumber, Integer pageSize, String searchKey, Role roleName) {

    List<User> users;

    // If no roleName is provided, fetch all users
    if (roleName == null) {
        users = userRepo.findAll(); // Fetch all users
    } else {
        // Step 1: Fetch the role entity from the roles table
        RoleEntity role = roleRepo.findByRoleName(String.valueOf(roleName))
                .stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Role not found"));

        // Step 2: Retrieve all user roles linked to the role ID
        List<UserRole> userRoles = userRoleRepo.findByRoleId(role.getId());

        // Step 3: Extract user IDs from the user roles
        List<String> userIds = userRoles.stream()
                .map(UserRole::getUserId)
                .collect(Collectors.toList());

        // Step 4: Retrieve users by their IDs
        users = userRepo.findByIdIn(userIds);
    }

    // Step 5: Apply searchKey filtering, if provided
    if (searchKey != null && !searchKey.isEmpty()) {
        users = users.stream()
                .filter(user -> user.getFirstName().toLowerCase().contains(searchKey.toLowerCase()) ||
                        user.getLastName().toLowerCase().contains(searchKey.toLowerCase()) ||
                        user.getEmail().toLowerCase().contains(searchKey.toLowerCase()))
                .collect(Collectors.toList());
    }

    // Step 6: Pagination
    int start = (pageNumber - 1) * pageSize;
    int end = Math.min(start + pageSize, users.size());
    List<User> paginatedUsers = users.subList(start, end);

    // Step 7: Fetch profiles of the paginated users
    List<String> paginatedUserIds = paginatedUsers.stream()
            .map(User::getId)
            .collect(Collectors.toList());

    List<UserProfile> userProfiles = userProfileRepo.findByUserIdIn(paginatedUserIds);

    // Step 8: Map users and profiles into UserAndProfile DTOs
    List<UserAndProfile> userAndProfiles = paginatedUsers.stream()
            .map(user -> {
                UserProfile matchedProfile = userProfiles.stream()
                        .filter(profile -> profile.getUserId().equals(user.getId()))
                        .findFirst()
                        .orElse(null);

                UserAndProfile dto = new UserAndProfile();
                dto.setUser(user);

                if (matchedProfile != null) {
                    dto.setId(matchedProfile.getProfileId());
                    dto.setUserId(matchedProfile.getUserId());
                    dto.setFirstName(matchedProfile.getFirstName());
                    dto.setLastName(matchedProfile.getLastName());
                    dto.setCreatedAt(matchedProfile.getCreatedAt());
                    dto.setSchoolId(matchedProfile.getSchoolId());
                    dto.setSchoolName(matchedProfile.getSchoolName());
                    dto.setDefaultAddressId(matchedProfile.getDefaultAddressId());
                    dto.setDefaultAddressType(matchedProfile.getDefaultAddressType());
                    dto.setClassAndSection(matchedProfile.getClassAndSection());
                    dto.setStatus(UserProfileStatus.ACTIVE);
                    dto.setDefault(matchedProfile.isDefault());
                    dto.setCreatedBy(matchedProfile.getCreatedBy());
                    dto.setUpdatedBy(matchedProfile.getUpdatedBy());
                }
                return dto;
            })
            .collect(Collectors.toList());

    // Step 9: Create and return a paginated response
    PageResponse<UserAndProfile> response = new PageResponse<>();
    response.setContent(userAndProfiles);
    response.setPageNumber(pageNumber);
    response.setPageSize(pageSize);
    response.setTotalElements(users.size());
    response.setTotalPages((int) Math.ceil((double) users.size() / pageSize));
    response.setFirst(pageNumber == 1);
    response.setLast(pageNumber == (int) Math.ceil((double) users.size() / pageSize));
    response.setNumberOfElements(userAndProfiles.size());

    return response;
}


    public List<User> getUsersByRole(Role roleName) {
        // Get the role ID from the role name
        RoleEntity role = roleRepo.findByRoleName(String.valueOf(roleName))
                .stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Role not found"));

        // Get user roles by roleId
        List<UserRole> userRoles = userRoleRepo.findByRoleId(role.getId());

        // Extract user IDs from the user roles
        List<String> userIds = userRoles.stream()
                .map(UserRole::getUserId)
                .collect(Collectors.toList());

        // Get users by user IDs
        return userRepo.findByIdIn(userIds);
    }





//@Override
//public List<UserProfileLimitedInfo> getAllUserAndProfiles(Role role, String searchKey) {
//
//    Query userQuery = new Query();
//    Map<String, String> queryString = new HashMap<>();
//    queryString.put("search", searchKey);
//
//    userQuery.addCriteria(Criteria.where("roles").is(role));
//    APIFeatures userFeatures = new APIFeatures(userQuery, queryString);
//    userFeatures.search();
//
//    List<User> users = mongoTemplate.find(userFeatures.getQuery(), User.class);
//
//    List<String> userIds = users.stream().map(User::getId).collect(Collectors.toList());
//    Query profileQuery = new Query(Criteria.where("userId").in(userIds));
//    APIFeatures profileFeatures = new APIFeatures(profileQuery, queryString);
//    profileFeatures.search();
//    List<UserProfile> userProfiles = mongoTemplate.find(profileFeatures.getQuery(), UserProfile.class);
//
//    List<UserProfileLimitedInfo> responseList = new ArrayList<>();
//    for (UserProfile profile : userProfiles) {
//        User user = users.stream()
//                .filter(u -> u.getId().equals(profile.getUserId()))
//                .findFirst()
//                .orElseThrow(() -> new UserNotFoundException("User not found for userId: " + profile.getUserId()));
//
//        String combinedInfo = user.getEmail() + " - " + profile.getFirstName() + " " + profile.getLastName();
//        responseList.add(new UserProfileLimitedInfo(user.getId(), profile.getProfileId(), combinedInfo));
//    }
//
//    return responseList;
//}


    public List<User> getAllUsersForExcelSheet() {
        return userRepo.findAll();
    }

    public void saveUsers(MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("File is empty!");
        }

        String fileType = file.getContentType();
        if (!"text/csv".equals(fileType)) {
            throw new IllegalArgumentException("Invalid file type. Please upload a CSV file.");
        }

        List<AddBulkOfUserByAdmin> users = parseCsvFile(file);
        List<User> userEntities = users.stream()
                .map(this::mapToUserEntity)
                .toList();

        userRepo.saveAll(userEntities);
    }

    private List<AddBulkOfUserByAdmin> parseCsvFile(MultipartFile file) throws IOException {
        List<AddBulkOfUserByAdmin> users = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            boolean isHeader = true;
            while ((line = reader.readLine()) != null) {
                if (isHeader) {
                    isHeader = false; // Skip the header row
                    continue;
                }
                String[] fields = line.split(",");
                if (fields.length < 6) {
                    throw new IllegalArgumentException("Invalid CSV format.");
                }

                AddBulkOfUserByAdmin user = new AddBulkOfUserByAdmin();
                user.setEmail(fields[0]);
                user.setPassword(fields[1]);
                user.setRole(Role.valueOf(fields[2].toUpperCase()));
                user.setMobile(fields[3]);
                user.setFirstName(fields[4]);
                user.setLastName(fields[5]);
                user.setSchoolId(fields.length > 6 ? fields[6] : null);
                user.setClassAndSection(fields.length > 7 ? fields[7] : null);
                user.setStatus(UserProfileStatus.valueOf(fields.length > 8 ? fields[8].toUpperCase() : "ACTIVE"));

                users.add(user);
            }
        }
        return users;
    }

    private User mapToUserEntity(AddBulkOfUserByAdmin dto) {
        User user = new User();
        user.setEmail(dto.getEmail());
        user.setPassword(dto.getPassword());
        user.setRoleId(String.valueOf(dto.getRole()));
        user.setPhoneNo(dto.getMobile());
        user.setFirstName(dto.getFirstName());
        user.setLastName(dto.getLastName());
        user.setSchoolId(dto.getSchoolId() != null ? (dto.getSchoolId()) : null);
        // user.setClassAndSection(dto.getClassAndSection());
        user.setStatus(UserStatus.ACTIVE);
        return user;
    }
//    @Override
//    public List<UserAndAllProfilesResponse> getAllUserWithProfile(Role role, String searchKey, String profileId) {
//            return userProfileRepo.getAllUserWithProfile(role, searchKey, profileId);
//    }

    @Autowired
    private MobileOtpTwilioConfig mobileOtpTwilioConfig;

    @Override
    public OtpVerificationResponse sendOtp(SendOtpMobileRequest request) {
        String recipientPhoneNumber = request.getMobileNumber();

        String otp = generateOtp();

        User user = userRepo.findByPhoneNo(recipientPhoneNumber);
        if (user == null) {
            user = new User();
            user.setPhoneNo(recipientPhoneNumber);
        }
        user.setOtp(otp);
        user.setPhoneNoVerified(false);
        userRepo.save(user);
        String formattedPhoneNumberForTwilio = "+91" + recipientPhoneNumber;
        Twilio.init(mobileOtpTwilioConfig.getACCOUNT_SID(), mobileOtpTwilioConfig.getAUTH_TOKEN());

        HashMap<String, String> otpMap = new HashMap<>();
        try {
            String messageBody = "Your one time password is: " + otp;

            Message message = Message.creator(
                    new PhoneNumber(formattedPhoneNumberForTwilio),
                    new PhoneNumber(mobileOtpTwilioConfig.getFROM_PHONE_NUMBER()),
                    messageBody
            ).create();

            otpMap.put(recipientPhoneNumber, otp);

            System.out.println("OTP sent successfully: SID = " + message.getSid());
            return new OtpVerificationResponse("OTP sent successfully", true);
        } catch (Exception e) {
            throw new RuntimeException("Error sending OTP: " + e.getMessage());
        }
    }

    public OtpVerificationResponse verifyOtp(VerifyOtpMobileRequest request) {
        User user = userRepo.findByPhoneNo(request.getMobileNumber());

        if (user == null) {
            return new OtpVerificationResponse("Mobile No. not found", false);
        }

        if (user.getOtp().equals(request.getOtp())) {
            user.setPhoneNoVerified(true);
            userRepo.save(user);
            return new OtpVerificationResponse("OTP verified successfully", true);
        } else {
            return new OtpVerificationResponse("Invalid OTP", true);
        }
    }

    private String generateOtp() {
        Random random = new Random();
        int otp = 100000 + random.nextInt(900000);
        return String.valueOf(otp);
    }

    public List<User> getUsersByStatus(UserStatus status) {
        return userRepo.findByStatus(status);
    }

    public List<NewlyOnboaredUserAndProfileResponse> getUsersByTimeframe(UserStatus status, LocalDateTime startTime, LocalDateTime endTime) {
        if (startTime == null || endTime == null) {
            throw new IllegalArgumentException("StartTime and EndTime cannot be null.");
        }

        List<User> users = userRepo.findUsersWithProfilesByCreatedAtBetweenAndStatus(startTime, endTime,status);

        List<NewlyOnboaredUserAndProfileResponse> newlyOnboaredUserAndProfileResponses = new ArrayList<>();

        for (User user : users) {
            NewlyOnboaredUserAndProfileResponse response = new NewlyOnboaredUserAndProfileResponse();

            NewlyOnboardedUser onboardedUser = new NewlyOnboardedUser();
            onboardedUser.setUserId(user.getId());
            onboardedUser.setFullName(user.getFirstName()+" "+user.getLastName());
            onboardedUser.setEmail(user.getEmail());
            onboardedUser.setMobile(user.getPhoneNo());
//            onboardedUser.setUserType(user.getUserType());
//            onboardedUser.setRole(Role.valueOf(user.getRoleId()));
            onboardedUser.setStatus(user.getStatus());
            onboardedUser.setCreatedAt(user.getCreatedAt());
            onboardedUser.setUpdatedAt(user.getUpdatedAt());

            List<UserProfile> userProfileList = userProfileRepo.findByUserId(user.getId());
            if (userProfileList != null) {
                List<NewlyOnboardedProfile> onboardedProfiles = new ArrayList<>();
                for (UserProfile userProfile : userProfileList) {
                    NewlyOnboardedProfile profile = new NewlyOnboardedProfile();
                    profile.setId(userProfile.getProfileId());
                    profile.setUserId(userProfile.getUserId());
                    profile.setFirstName(userProfile.getFirstName());
                    profile.setLastName(userProfile.getLastName());
                    profile.setDob(userProfile.getDateOfBirth());
                    profile.setAge(findAgeFromDob(userProfile.getDateOfBirth()));
                    profile.setSchoolId(userProfile.getSchoolId());
                    profile.setSchoolName(userProfile.getSchoolName());
                    profile.setAdminComment(userProfile.getAdminComment());
                  //  profile.setStatus(userProfile.getStatus());
                    profile.setDefaultAddressType(userProfile.getDefaultAddressType());
                    profile.setDefaultAddressId(userProfile.getDefaultAddressId());
                    profile.setCreatedAt(userProfile.getCreatedAt());
                    profile.setUpdatedAt(userProfile.getUpdatedAt());
                    profile.setDefault(userProfile.isDefault());

                    onboardedProfiles.add(profile);
                }
                response.setNewlyOnboardedProfiles(onboardedProfiles);
            }

            response.setNewlyOnboardedUser(onboardedUser);
            newlyOnboaredUserAndProfileResponses.add(response);
        }

        return newlyOnboaredUserAndProfileResponses;
    }

}




