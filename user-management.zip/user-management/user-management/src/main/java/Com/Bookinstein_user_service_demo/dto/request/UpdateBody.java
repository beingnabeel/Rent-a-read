package Com.Bookinstein_user_service_demo.dto.request;


import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UpdateBody {
    @NotBlank
    private String firstName;
    @NotBlank
    private String lastName;
    @NotBlank(message = "Only contain 10 digit and not blank !!")
    @Pattern(regexp = "^[0-9]{10}$", message = "Mobile number must be exactly 10 digits")
    private String phoneNo;
    @Past(message = "Date of birth must be in the past")
    @NotNull(message = "accept the date like 2024-05-30")
    private LocalDate dateOfBirth;
}
