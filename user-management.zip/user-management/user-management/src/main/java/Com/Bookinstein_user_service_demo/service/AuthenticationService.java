package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.dto.request.LoginRequest;
import Com.Bookinstein_user_service_demo.dto.request.UserRequestBody;
import Com.Bookinstein_user_service_demo.dto.response.LoginResponse;
import Com.Bookinstein_user_service_demo.dto.response.SuccessResponse;
import jakarta.validation.Valid;

import javax.management.relation.RoleNotFoundException;

public interface AuthenticationService
{

    SuccessResponse createUser(@Valid UserRequestBody userRequestBody) ;
    LoginResponse authenticate(LoginRequest loginRequest);
}
