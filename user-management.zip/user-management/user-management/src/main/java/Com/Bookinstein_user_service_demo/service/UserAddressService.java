package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.dto.request.DefaultAddressBody;
import Com.Bookinstein_user_service_demo.dto.request.UserAddressBody;
import Com.Bookinstein_user_service_demo.dto.response.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;

import java.util.List;

public interface UserAddressService {

    SuccessResponse addUserAddress(String id, String profileId, UserAddressBody userAddressBody, HttpServletRequest request);

    DefaultAddress getDefaultUserAddresses(String userId, String profileId);

    List<PostalResponse> getPostOffice(@Positive Long pincode);

    SuccessResponse updateDefaultUserAddresses(String id, String profileId, @Valid DefaultAddressBody defaultAddressBody);

   // void deleteUserAddress(String profileId, String defaultAddressId);
    void deleteUserAddress(String addressId, HttpServletRequest request);

    SuccessAddressResponse updateUserAddress(String addressId, @Valid UserAddressBody userAddressBody, HttpServletRequest request);


    List<AddressBodyResponse> getAllUserAddresses(String userId);

    SuccessResponse addUserAddressByUserId(@Valid UserAddressBody userAddressBody, HttpServletRequest request);
}
