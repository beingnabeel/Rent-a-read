package Com.Bookinstein_user_service_demo.dto.response;

import Com.Bookinstein_user_service_demo.enums.AddressType;
import lombok.*;

import java.time.Instant;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserAddress {
    private String id;
    private String userId;
    private String house;
    private String street;
    private String landmark;
    private Long pincode;
    private String city;
    private String state;
    private String country;
    private AddressType addressType = AddressType.HOME;
    private boolean isDefault = true;
    private Instant createdAt;
    private String createdBy;
    private Instant updatedAt;
    private String updatedBy;

}
