package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.dto.request.PermissionRequest;
import Com.Bookinstein_user_service_demo.dto.request.RolePermissionRequest;
import Com.Bookinstein_user_service_demo.entities.Permission;
import Com.Bookinstein_user_service_demo.entities.RolePermission;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.entities.UserRole;
import Com.Bookinstein_user_service_demo.exception.DuplicatePermissionException;
import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
import Com.Bookinstein_user_service_demo.repository.PermissionRepository;
import Com.Bookinstein_user_service_demo.repository.RolePermissionRepository;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import Com.Bookinstein_user_service_demo.repository.UserRoleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class PermissionServiceImpl implements PermissionService
{
    private final PermissionRepository permissionRepository;
    private final RolePermissionRepository rolePermissionRepository;
    private final UserRoleRepository userRoleRepository;
    private final UserRepo userRepo;

    @Override
    public Permission createPermission(PermissionRequest permissionRequest) {
        try {
            String permissionName = permissionRequest.getPermissionName();

            if (permissionRepository.existsByPermissionName(permissionName)) {
                throw new DuplicatePermissionException("Permission '" + permissionName + "' already exists in the database.");
            }
            Permission permission = new Permission();
            permission.setPermissionName(permissionName);
            permission.setCreatedAt(java.time.Instant.now());
            permission.setUpdatedAt(java.time.Instant.now());

            return permissionRepository.save(permission);
        } catch (DuplicatePermissionException e) {
            log.error("Validation error: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("An unexpected error occurred while creating the role: {}", e.getMessage());
            throw new RuntimeException("Error while creating role", e);
        }
    }

    public List<Permission> getAllPermissions() {
        return permissionRepository.findAll();
    }

    @Override
    public void assignPermissionToRole(String roleId, RolePermissionRequest rolePermissionRequest) {

            RolePermission rolePermission1 = new RolePermission();
            rolePermission1.setRoleId(roleId);
            rolePermission1.setPermissionIds(rolePermissionRequest.getPermissionIds());
            rolePermission1.setCreatedAt(java.time.Instant.now());
            rolePermission1.setUpdatedAt(java.time.Instant.now());
            rolePermissionRepository.save(rolePermission1);
        }

     @Override
     public List<Permission> getPermissionsByUserId(String userId) {
        if (!isUserExists(userId)) {
        throw new UserNotFoundException("User with ID " + userId + " does not exist.");
      }

    List<UserRole> userRoles = userRoleRepository.findByUserId(userId);
    List<String> roleIds = userRoles.stream()
            .map(UserRole::getRoleId)
            .collect(Collectors.toList());

    List<RolePermission> rolePermissions = rolePermissionRepository.findByRoleIdIn(roleIds);

    Set<String> permissionIds = rolePermissions.stream()
            .flatMap(rolePermission -> rolePermission.getPermissionIds().stream())
            .collect(Collectors.toSet());

    return permissionRepository.findByIdIn(new ArrayList<>(permissionIds));
   }

    @Override
    public List<Permission> getPermissionsByRoleId(String roleId) {

        List<RolePermission> rolePermissions = rolePermissionRepository.findByRoleId(roleId);

        List<String> permissionIds = rolePermissions.stream()
                .flatMap(rolePermission -> rolePermission.getPermissionIds().stream())
                .collect(Collectors.toList());

        return permissionRepository.findAllById(permissionIds);
    }

    private boolean isUserExists(String userId) {return userRepo.existsById(userId);}

}

