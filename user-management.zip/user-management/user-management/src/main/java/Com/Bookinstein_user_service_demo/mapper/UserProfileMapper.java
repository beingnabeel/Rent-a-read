package Com.Bookinstein_user_service_demo.mapper;

import Com.Bookinstein_user_service_demo.dto.request.AddUserByAdminRequestBody;
import Com.Bookinstein_user_service_demo.dto.request.UserProfilesBody;
import Com.Bookinstein_user_service_demo.entities.UserProfile;
import org.mapstruct.Mapper;


@Mapper
public interface UserProfileMapper {

    UserProfile addUserProfileBodyToUserProfile(UserProfilesBody userProfilesBody);

    UserProfile addUserByAdminRequestBodyToUserProfile(AddUserByAdminRequestBody addUserByAdminRequestBody);
}
