package Com.Bookinstein_user_service_demo.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserAddressBody
{
    @NotBlank(message = "house must be required")
    private String house;
    @NotBlank(message = "street must be required")
    private String street;
    @NotBlank(message = "Landmark must be required")
    private String landmark;
    @NotBlank(message = "city must be required")
    private String city;
    @NotBlank(message = "state must be required")
    private String state;
    @NotBlank(message = "country must be required")
    private String country;
    @NotNull(message = "pincode must be required")
    @Pattern(regexp = "^[0-9]{6}$", message = "Pin code must be exactly 6 digits")
    private String pincode;
   // private AddressType addressType;
    private boolean isDefault;
    private boolean isDeleted;
}
