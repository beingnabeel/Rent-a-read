package Com.Bookinstein_user_service_demo.exception;

public class WriteResponseException extends RuntimeException {
    public WriteResponseException(String message, Throwable cause) {
        super(message, cause);
    }
}