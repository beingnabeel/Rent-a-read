package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.Client.SchoolClient;
import Com.Bookinstein_user_service_demo.dto.request.DefaultAddressBody;
import Com.Bookinstein_user_service_demo.dto.request.UserAddressBody;
import Com.Bookinstein_user_service_demo.dto.response.*;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.entities.UserAddressEntity;
import Com.Bookinstein_user_service_demo.entities.UserProfile;
import Com.Bookinstein_user_service_demo.enums.AddressType;
import Com.Bookinstein_user_service_demo.enums.WeekDay;
import Com.Bookinstein_user_service_demo.exception.ResourceNotFoundException;
import Com.Bookinstein_user_service_demo.exception.UnauthorizedException;
import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
import Com.Bookinstein_user_service_demo.repository.UserAddressRepo;
import Com.Bookinstein_user_service_demo.repository.UserProfileRepo;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class UserAddressServiceImpl implements UserAddressService {
    private final UserAddressRepo userAddressRepo;
    private final UserProfileRepo userProfileRepo;
    private final UserRepo userRepo;
    private final JwtService jwtService;
    private final RestTemplate restTemplate;
    private final SchoolClient schoolClient;

    @Value("${postal.api.url}")
    private String postalApiUrl;

    public UserAddressServiceImpl(UserAddressRepo userAddressRepo, UserProfileRepo userProfileRepo, UserRepo userRepo, JwtService jwtService, RestTemplate restTemplate, SchoolClient schoolClient) {
        this.userAddressRepo = userAddressRepo;
        this.userProfileRepo = userProfileRepo;
        this.userRepo = userRepo;
        this.jwtService = jwtService;
        this.restTemplate = restTemplate;
        this.schoolClient = schoolClient;
    }

//    @Override
//    public SuccessResponse addUserAddress(String id, String profileId, UserAddressBody userAddressBody, HttpServletRequest request) {
//        final String authHeader = request.getHeader("Authorization");
//        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
//            throw new IllegalStateException("Invalid Authorization header");
//        }
//        final String jwt = authHeader.substring(7);
//        String currentUserId = jwtService.extractUserId(jwt);
//
//        if (!currentUserId.equals(id)) {
//            throw new UnauthorizedException("You are not authorized to perform this action.");
//        }
//
//        if (id == null || id.isEmpty()) {
//            throw new IllegalArgumentException("User ID cannot be null or empty");
//        }
//        User user = userRepo.findById(id)
//                .orElseThrow(() -> new UserNotFoundException("Invalid or expired token"));
//
//        UserAddressEntity userAddressEntity = new UserAddressEntity();
//        userAddressEntity.setUserId(id);
////        userAddressEntity.setDefault(userAddressBody.isDefault());
//        userAddressEntity.setHouse(userAddressBody.getHouse());
//        userAddressEntity.setStreet(userAddressBody.getStreet());
//        userAddressEntity.setLandmark(userAddressBody.getLandmark());
//        userAddressEntity.setPincode(String.valueOf(userAddressBody.getPincode()));
//        userAddressEntity.setCity(userAddressBody.getCity());
//        userAddressEntity.setState(userAddressBody.getState());
//        userAddressEntity.setCountry(userAddressBody.getCountry());
//
//        userAddressRepo.save(userAddressEntity);
//        if(userAddressBody.isDefault()) {
//            Optional<UserProfile> userProfileEntityOptional = userProfileRepo.findById(profileId);
//            if(userProfileEntityOptional.isPresent()) {
//                UserProfile userProfileEntity = userProfileEntityOptional.get();
//                userProfileEntity.setDefaultAddressType(AddressType.HOME);
//                userProfileEntity.setDefaultAddressId(userAddressEntity.getId());
//                userProfileRepo.save(userProfileEntity);
//            }
//        }
//        return SuccessResponse.builder()
//                .message("user address created")
//                .body(userAddressBody)
//                .build();
//    }


//    @Override
//    public UserAddresses getUserAddresses(String id, String profileId, Integer pageNumber, Integer pageSize) {
//        UserAddresses userAddresses = UserAddresses.builder().build();
//        String defaultAddressId = null;
//
//        Optional<UserProfile> userProfileEntityOptional = userProfileRepo.findById(profileId);
//        if (userProfileEntityOptional.isPresent()) {
//            UserProfile userProfileEntity = userProfileEntityOptional.get();
//
//
//            if (AddressType.HOME.equals(userProfileEntity.getDefaultAddressType())) {
//                defaultAddressId = userProfileEntity.getDefaultAddressId();
//            }
//
////            if(userProfileEntity.getSchoolId() != null &&) {
////               // SchoolAddress schoolAddress = getSchool(userProfileEntity.getSchoolId());
////               // PostOffice postOffice = getPostOffice(schoolAddress.getPincode());
////                if(AddressType.SCHOOL.equals(userProfileEntity.getDefaultAddressType())) {
////                    schoolAddress.setDefault(true);
////                }
////                schoolAddress.setCity(.getCity());
////                schoolAddress.setState(postOffice.getState());
////                schoolAddress.setCountry(postOffice.getCountry());
////                userAddresses.setSchoolAddress(schoolAddress);
////            }
//             if (AddressType.SCHOOL.equals(userProfileEntity.getDefaultAddressType())) {
//                defaultAddressId = userProfileEntity.getDefaultAddressId();
//            }
//        }
//
//        final String defaultAddressIdFinal = defaultAddressId;
//
//        Pageable pageable = PageRequest.of(pageNumber - 1, pageSize);
//
//        Page<UserAddressEntity> addressEntitiesPage = userAddressRepo.findAllByUserId(id, pageable);
//
//        PageResponse<UserAddress> pageResponse = new PageResponse<>();
//
//        List<UserAddress> userAddressList = new ArrayList<>();
//
//        for (UserAddressEntity addressEntity : addressEntitiesPage.getContent()) {
//            UserAddress userAddress = new UserAddress();
//
//            userAddress.setId(addressEntity.getId());
//            userAddress.setUserId(addressEntity.getUserId());
//            userAddress.setHouse(addressEntity.getHouse());
//            userAddress.setStreet(addressEntity.getStreet());
//            userAddress.setLandmark(addressEntity.getLandmark());
//            userAddress.setPincode(Long.valueOf(addressEntity.getPincode()));
//            userAddress.setCity(addressEntity.getCity());
//            userAddress.setState(addressEntity.getState());
//            userAddress.setCountry(addressEntity.getCountry());
//
//            if (addressEntity.getId().equals(defaultAddressIdFinal)) {
//                userAddress.setDefault(true);
//            } else {
//                userAddress.setDefault(false);
//            }
//
//            userAddressList.add(userAddress);
//        }
//
//        pageResponse.setContent(userAddressList);
//        pageResponse.setPageNumber(pageNumber);
//        pageResponse.setPageSize(pageSize);
//        pageResponse.setTotalPages(addressEntitiesPage.getTotalPages());
//        pageResponse.setTotalElements(addressEntitiesPage.getTotalElements());
//        pageResponse.setFirst(addressEntitiesPage.isFirst());
//        pageResponse.setLast(addressEntitiesPage.isLast());
//        pageResponse.setNumberOfElements(addressEntitiesPage.getNumberOfElements());
//
//        userAddresses.setUserAddresses(pageResponse);
//
//        return userAddresses;
//    }


    @Override
    public SuccessResponse addUserAddress(String id, String profileId, UserAddressBody userAddressBody, HttpServletRequest request) {
        final String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new IllegalStateException("Invalid Authorization header");
        }
        final String jwt = authHeader.substring(7);
        String currentUserId = jwtService.extractUserId(jwt);

        if (!currentUserId.equals(id)) {
            throw new UnauthorizedException("You are not authorized to perform this action.");
        }

        if (id == null || id.isEmpty()) {
            throw new IllegalArgumentException("User ID cannot be null or empty");
        }

        User user = userRepo.findById(id)
                .orElseThrow(() -> new UserNotFoundException("Invalid or expired token"));

        UserProfile userProfileEntity = userProfileRepo.findByProfileIdAndIsDefault(profileId, true)
                .orElseThrow(() -> new IllegalArgumentException("Profile not found for the given profileId"));

        Optional<UserAddressEntity> existingDefaultAddress = userAddressRepo.findByUserIdAndIsDefaultTrue(id);

        if (existingDefaultAddress.isPresent() && userAddressBody.isDefault()) {
            UserAddressEntity currentDefaultAddress = existingDefaultAddress.get();
            currentDefaultAddress.setDefault(false);
            userAddressRepo.save(currentDefaultAddress);
        }

        UserAddressEntity userAddressEntity = new UserAddressEntity();
        userAddressEntity.setUserId(id);
        userAddressEntity.setDefault(userAddressBody.isDefault());
        userAddressEntity.setHouse(userAddressBody.getHouse());
        userAddressEntity.setStreet(userAddressBody.getStreet());
        userAddressEntity.setLandmark(userAddressBody.getLandmark());
        userAddressEntity.setPincode(String.valueOf(userAddressBody.getPincode()));
        userAddressEntity.setCity(userAddressBody.getCity());
        userAddressEntity.setState(userAddressBody.getState());
        userAddressEntity.setCountry(userAddressBody.getCountry());

        userAddressRepo.save(userAddressEntity);

        if (userAddressBody.isDefault()) {
            Optional<UserProfile> userProfileEntityOptional = userProfileRepo.findById(profileId);
            if (userProfileEntityOptional.isPresent()) {
                UserProfile userProfile = userProfileEntityOptional.get();
                userProfile.setDefaultAddressType(AddressType.HOME);
                userProfile.setDefaultAddressId(userAddressEntity.getId());
                userProfileRepo.save(userProfile);
            }
        }

        return SuccessResponse.builder()
                .message("user address created")
                .body(userAddressBody)
                .build();
    }


//    @Override
//    public DefaultAddress getDefaultUserAddresses(String userId, String profileId) {
//        try {
//            UserProfile userProfileEntity = userProfileRepo.findByUserIdAndProfileId(userId, profileId)
//                    .orElseThrow(() -> {
//                        log.error("User profile not found for userId: {} and profileId: {}", userId, profileId);
//                        return new UserNotFoundException("User profile not found.");
//                    });
//        AddressType addressType = null;
//        String addressId = null;
//        String address = null;
//        Long pincode = null;
//        WeekDay weekDay = null;
//        if(AddressType.HOME.equals(userProfileEntity.getDefaultAddressType())) {
//            Optional<UserAddressEntity> userAddressEntityOptional = userAddressRepo.findById(userProfileEntity.getDefaultAddressId());
//            if (userAddressEntityOptional.isPresent()) {
//                UserAddressEntity userAddressEntity = userAddressEntityOptional.get();
//                addressType = userProfileEntity.getDefaultAddressType();
//                addressId = userAddressEntity.getId();
//                address = getUserAddressAsString(userAddressEntity);
//                pincode = Long.valueOf(userAddressEntity.getPincode());
//            }
//
//        } else if(AddressType.SCHOOL.equals(userProfileEntity.getDefaultAddressType())) {
//            Optional<UserAddressEntity> userAddressEntityOptional = userAddressRepo.findById(userProfileEntity.getDefaultAddressId());
//            if (userAddressEntityOptional.isPresent()) {
//                UserAddressEntity userAddressEntity = userAddressEntityOptional.get();
//                addressType = userProfileEntity.getDefaultAddressType();
//                addressId = userAddressEntity.getId();
//                address = getUserAddressAsString(userAddressEntity);
//                pincode = Long.valueOf(userAddressEntity.getPincode());
//            }
//        }
//        return DefaultAddress.builder()
//                .defaultAddressType(addressType)
//                .defaultAddressId(addressId)
//                .address(address)
//                .pincode(pincode)
//              //  .weekDay(weekDay)
//                .build();
//
//        } catch (UserNotFoundException ex) {
//            log.error("Error fetching default address: {}", ex.getMessage(), ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error fetching default address: {}", ex.getMessage(), ex);
//            throw ex;
//        }
//    }

    @Override
    public DefaultAddress getDefaultUserAddresses(String userId, String profileId) {
        try {
            UserProfile userProfileEntity = userProfileRepo.findByUserIdAndProfileId(userId, profileId)
                    .orElseThrow(() -> {
                        log.error("User profile not found for userId: {} and profileId: {}", userId, profileId);
                        return new UserNotFoundException("User profile not found.");
                    });

            AddressType addressType = null;
            String addressId = null;
            String address = null;
            Long pincode = null;

            if (AddressType.HOME.equals(userProfileEntity.getDefaultAddressType())) {
                Optional<UserAddressEntity> userAddressEntityOptional = userAddressRepo.findById(userProfileEntity.getDefaultAddressId());
                if (userAddressEntityOptional.isPresent()) {
                    UserAddressEntity userAddressEntity = userAddressEntityOptional.get();
                    addressType = userProfileEntity.getDefaultAddressType();
                    addressId = userAddressEntity.getId();
                    address = getUserAddressAsString(userAddressEntity);
                    pincode = userAddressEntity.getPincode() != null ? Long.valueOf(userAddressEntity.getPincode()) : null;
                }
            }  else if (AddressType.SCHOOL.equals(userProfileEntity.getDefaultAddressType())) {
                SchoolAddress schoolResponse = schoolClient.getSchool(userProfileEntity.getDefaultAddressId());
                log.debug("School response: {}", schoolResponse);

                if (schoolResponse != null) {
                    addressType = userProfileEntity.getDefaultAddressType();
                    addressId = String.valueOf(schoolResponse.getId());
                    address = getSchoolAddressAsString(schoolResponse);
                    pincode = schoolResponse.getPincode() != null ? Long.valueOf(schoolResponse.getPincode()) : null;

                    log.debug("Resolved school address: {}, pincode: {}", address, pincode);
                }
            }

            return DefaultAddress.builder()
                    .defaultAddressType(addressType)
                    .defaultAddressId(addressId)
                    .address(address)
                    .pincode(pincode) // This will remain null if pincode is not present
                    .build();

        } catch (Exception e) {
            log.error("Error occurred while fetching default address for userId: {} and profileId: {}", userId, profileId, e);
            throw e;
        }
    }


    private String getUserAddressAsString(UserAddressEntity userAddressEntity) {
        return userAddressEntity.getHouse() +", "+
                userAddressEntity.getStreet()  +" ,"+
                userAddressEntity.getLandmark()  +","+
                userAddressEntity.getCity() + ", " + userAddressEntity.getState() + ", " +
                userAddressEntity.getCountry();
    }
    private String getSchoolAddressAsString(SchoolAddress schoolAddress) {
        return schoolAddress.getName() + " " + schoolAddress.getBranch() + ",\n" +
                schoolAddress.getAddress();
    }


    public List<PostalResponse> getPostOffice(Long pincode) {
        String thirdPartyApiUrl = postalApiUrl + "/" + pincode;
        ResponseEntity<String> responseEntity = restTemplate.exchange(
                thirdPartyApiUrl,
                HttpMethod.GET,
                null,
                String.class
        );
        String rawResponse = responseEntity.getBody();
        System.out.println("Raw API Response: " + rawResponse);

        ObjectMapper objectMapper = new ObjectMapper();
        List<PostalResponse> responseList;
        try {
            responseList = objectMapper.readValue(rawResponse, new TypeReference<List<PostalResponse>>() {});
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Error parsing response", e);
        }

        System.out.println("API Response: " + responseList);
        if (responseList == null || responseList.isEmpty()) {
            throw new ResourceNotFoundException("Invalid Pincode or no data found for: " + pincode);
        }
        return responseList;
    }

    @Override
    public SuccessResponse updateDefaultUserAddresses(String userId, String profileId, DefaultAddressBody defaultAddressBody) {
        UserProfile userProfileEntity = userProfileRepo.findByUserIdAndProfileId(userId, profileId)
                .orElseThrow(() -> new UserNotFoundException("User profile not found."));
        Optional<UserProfile> userProfile = userProfileRepo.findByDefaultAddressId(defaultAddressBody.getAddressId());

        userProfileEntity.setDefaultAddressType(defaultAddressBody.getAddressType());
        userProfileEntity.setDefaultAddressId(defaultAddressBody.getAddressId());
        //  userProfileEntity.setDefaultAddressId(userProfile.get().getDefaultAddressId());

        userProfileRepo.save(userProfileEntity);
        return SuccessResponse.builder()
                .message("default user address updated").body(userProfileEntity)
                .build();
    }

//    @Override
//    public void deleteUserAddress(String userId, String addressId) {
//        Optional<UserAddressEntity> addressEntityOptional = userAddressRepo.findByIdAndUserId(addressId, userId);
//        if (addressEntityOptional.isPresent()) {
//            userAddressRepo.deleteById(addressId);
//            log.info("Successfully deleted address with id: {} for userId: {}", addressId, userId);
//        }
//        else {
//            log.error("Address not found for addressId: {} and userId: {}", addressId, userId);
//            throw new ResourceNotFoundException("Address not found for addressId: " + addressId + " and userId: " + userId);
//        }
//    }

    @Override
    public void deleteUserAddress(String addressId, HttpServletRequest request) {
        // Validate and extract the Authorization header
        final String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new IllegalStateException("Authorization header is missing or invalid");
        }

        // Extract the JWT and user ID from it
        final String jwt = authHeader.substring(7);
        String currentUserId;
        try {
            currentUserId = jwtService.extractUserId(jwt);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to extract user ID from the JWT", e);
        }

        // Validate if the user exists
        Optional<User> userOptional = userRepo.findById(currentUserId);
        if (userOptional.isEmpty()) {
            throw new IllegalStateException("User not found with ID: " + currentUserId);
        }

        // Validate if the address exists and is not already deleted
        Optional<UserAddressEntity> addressEntityOptional = userAddressRepo.findByIdAndIsDeletedFalse(addressId);
        if (addressEntityOptional.isEmpty()) {
            log.error("Address not found or already deleted. AddressId: {}, UserId: {}", addressId, currentUserId);
            throw new ResourceNotFoundException("Address not found or already deleted for AddressId: " + addressId);
        }

        // Mark the address as deleted and save it
        UserAddressEntity addressEntity = addressEntityOptional.get();
        addressEntity.setIsDeleted(true);
        userAddressRepo.save(addressEntity);

        log.info("Successfully marked address with ID: {} as deleted for User ID: {}", addressId, currentUserId);
    }

//    @Override
//    public void deleteUserAddress(String userId, String addressId) {
//        try {
//        Optional<UserProfile> userProfileOptional = userProfileRepo.findByUserIdAndDefaultAddressId(userId, addressId);
//        if (userProfileOptional.isEmpty()) {
//            log.error("User profile not found for userId: {}", userId);
//            throw new ResourceNotFoundException("User profile not found for userId: " + userId);
//        }
//        UserProfile userProfile = userProfileOptional.get();
//
//        boolean isDefaultAddress = addressId.equals(userProfile.getDefaultAddressId());
//        if (isDefaultAddress) {
//            userProfile.setDefaultAddressId(null);
//            userProfile.setDefaultAddressType(null);
//            userProfileRepo.save(userProfile);
//        }
//
//        Optional<UserAddressEntity> addressEntityOptional = userAddressRepo.findByIdAndUserId(addressId, userId);
//        if (addressEntityOptional.isPresent()) {
//            userAddressRepo.deleteById(addressId);
//            log.info("Successfully deleted address with id: {} for userId: {}", addressId, userId);
//        } else {
//            log.error("Address not found for addressId: {} and userId: {}", addressId, userId);
//            throw new ResourceNotFoundException("Address not found for addressId: " + addressId + " and userId: " + userId);
//        }
//        } catch (ResourceNotFoundException ex) {
//            log.error("Error during address deletion: {}", ex.getMessage(), ex);
//            throw ex;
//        } catch (Exception ex) {
//            log.error("Unexpected error during address deletion: {}", ex.getMessage(), ex);
//            throw ex;
//        }
//    }


    @Override
    public SuccessAddressResponse updateUserAddress(String addressId, UserAddressBody userAddressBody, HttpServletRequest request) {

        // Extract the Authorization header and validate the JWT
        final String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new IllegalStateException("Authorization header is missing or invalid");
        }
        final String jwt = authHeader.substring(7);
        String currentUserId = jwtService.extractUserId(jwt);

        // Validate the user making the request
        if (currentUserId == null || currentUserId.isEmpty()) {
            throw new IllegalArgumentException("Unable to identify the current user from the JWT");
        }

        // Validate if the provided address ID exists
        UserAddressEntity userAddressEntity = userAddressRepo.findById(addressId)
                .orElseThrow(() -> new ResourceNotFoundException("Address not found with ID: " + addressId));

        // Ensure the user ID matches the owner of the address
        if (!userAddressEntity.getUserId().equals(currentUserId)) {
            throw new UnauthorizedException("You are not authorized to update this address");
        }

        // Update the address fields
        userAddressEntity.setHouse(userAddressBody.getHouse());
        userAddressEntity.setStreet(userAddressBody.getStreet());
        userAddressEntity.setLandmark(userAddressBody.getLandmark());
        userAddressEntity.setCity(userAddressBody.getCity());
        userAddressEntity.setState(userAddressBody.getState());
        userAddressEntity.setCountry(userAddressBody.getCountry());
        userAddressEntity.setPincode(String.valueOf(userAddressBody.getPincode()));
        userAddressEntity.setIsDeleted(userAddressBody.isDeleted());
        userAddressEntity.setUpdatedAt(Instant.now());
        userAddressEntity.setUpdatedBy(currentUserId);
        userAddressEntity.setIsDeleted(userAddressBody.isDeleted());

        if (userAddressBody.isDefault()) {
            Optional<UserAddressEntity> currentDefaultAddress = userAddressRepo.findByUserIdAndIsDefault(currentUserId, true);
            if (currentDefaultAddress.isPresent()) {
                UserAddressEntity defaultEntity = currentDefaultAddress.get();
                defaultEntity.setDefault(false); // Remove default flag from the existing default address
                userAddressRepo.save(defaultEntity);
            }

             userAddressEntity.setDefault(true); // Set the requested address as default
           } else {
           userAddressEntity.setDefault(false); // Explicitly set the requested address as non-default if default is false
         }

        // Save the updated address
        userAddressRepo.save(userAddressEntity);

        // Return success response
        return SuccessAddressResponse.builder()
                .message("User address updated successfully")
                .build();
    }

    public List<AddressBodyResponse> getAllUserAddresses(String userId) {
        List<UserAddressEntity> userAddressEntities = userAddressRepo.findByUserId(userId);

        List<AddressBodyResponse> addressList = userAddressEntities.stream()
                .map(address -> {
                    AddressBodyResponse response = new AddressBodyResponse();
                    response.setId(address.getId());
                    response.setUserId(address.getUserId());
                    response.setHouse(address.getHouse());
                    response.setStreet(address.getStreet());
                    response.setLandmark(address.getLandmark());
                    response.setCity(address.getCity());
                    response.setState(address.getState());
                    response.setCountry(address.getCountry());
                    response.setPincode(Long.valueOf(address.getPincode()));
                    response.setIsDefault(address.isDefault());
                    response.setDeleted(address.getIsDeleted());
                    return response;
                })
                .collect(Collectors.toList());

        return addressList;
    }

    @Override
    public SuccessResponse addUserAddressByUserId(UserAddressBody userAddressBody, HttpServletRequest request) {
        final String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            throw new IllegalStateException("Invalid Authorization header");
        }
        final String jwt = authHeader.substring(7);
        String currentUserId = jwtService.extractUserId(jwt);
        Optional<User> user = userRepo.findById(currentUserId);
        if (user.isEmpty()) {
            throw new IllegalStateException("User not found with ID: " + currentUserId);
        }
        // Create a new UserAddressEntity for the new address
        UserAddressEntity userAddressEntity = new UserAddressEntity();
        userAddressEntity.setUserId(user.get().getId());
        userAddressEntity.setDefault(userAddressBody.isDefault());
        userAddressEntity.setHouse(userAddressBody.getHouse());
        userAddressEntity.setStreet(userAddressBody.getStreet());
        userAddressEntity.setLandmark(userAddressBody.getLandmark());
        userAddressEntity.setPincode(String.valueOf(userAddressBody.getPincode()));
        userAddressEntity.setCity(userAddressBody.getCity());
        userAddressEntity.setState(userAddressBody.getState());
        userAddressEntity.setIsDeleted(userAddressBody.isDeleted());
        userAddressEntity.setCountry(userAddressBody.getCountry());

        if (userAddressBody.isDefault()) {
            Optional<UserAddressEntity> defaultUserAddressEntity = userAddressRepo.findByUserIdAndIsDefault(currentUserId, true);
            if (defaultUserAddressEntity.isPresent()) {
                UserAddressEntity defaultEntity = defaultUserAddressEntity.get();
                defaultEntity.setDefault(false);
                userAddressRepo.save(defaultEntity);
            }
        }

        System.out.println("Final isDefault to be saved: " + userAddressEntity.isDefault());
        userAddressRepo.save(userAddressEntity);

        return new SuccessResponse("Address added successfully", true);
    }

}

