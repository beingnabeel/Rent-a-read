package Com.Bookinstein_user_service_demo.controller;

import Com.Bookinstein_user_service_demo.dto.request.PermissionRequest;
import Com.Bookinstein_user_service_demo.dto.request.RolePermissionRequest;
import Com.Bookinstein_user_service_demo.entities.Permission;
import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
import Com.Bookinstein_user_service_demo.service.PermissionService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@SecurityRequirement(name = "Authorization")
@RequestMapping("/permissions")
public class PermissionController
{
    @Autowired
    private PermissionService permissionService;

    @PostMapping("/create-permission")
    public ResponseEntity<Permission> createPermission(@RequestBody @Valid PermissionRequest permissionRequest) {
        Permission createdPermission = permissionService.createPermission(permissionRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPermission);
    }

    @GetMapping("/All-Permission")
    public List<Permission> getAllPermissions() {
        return permissionService.getAllPermissions();
    }

    @PostMapping("/assignPermission/role/{roleId}")
    public void assignPermissionToRole(@PathVariable String roleId, RolePermissionRequest rolePermission) {
        permissionService.assignPermissionToRole(roleId, rolePermission);
    }
    @GetMapping("GetAllPermissionOfUser/{userId}/")
    public ResponseEntity<List<Permission>> getPermissionsByUserId(@PathVariable String userId) {
        try {
            List<Permission> permissions = permissionService.getPermissionsByUserId(userId);
            return ResponseEntity.ok(permissions);
        } catch (UserNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
