package Com.Bookinstein_user_service_demo.exception;

public class ExpiredTokenException extends  RuntimeException{
    public ExpiredTokenException(String message) {
        super(message);
    }
}
