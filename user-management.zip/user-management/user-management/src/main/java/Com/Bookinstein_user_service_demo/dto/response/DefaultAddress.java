package Com.Bookinstein_user_service_demo.dto.response;

import Com.Bookinstein_user_service_demo.enums.AddressType;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class DefaultAddress {
    private AddressType defaultAddressType;
    private String defaultAddressId;
    private String address;
    private Long pincode;
   // private WeekDay weekDay;
}