package Com.Bookinstein_user_service_demo.enums;

import java.time.Duration;
import java.util.Arrays;

public enum TimeFrame {
    LAST_DAY(Duration.ofDays(1)),
    LAST_WEEK(Duration.ofDays(7)),
    LAST_MONTH(Duration.ofDays(30)),
    LAST_6_MONTHS(Duration.ofDays(180));

    private Duration duration;

    TimeFrame(Duration duration) {
        this.duration = duration;
    }

    public Duration getDuration() {
        return duration;
    }

    public static TimeFrame fromCode(String code) {
        return Arrays.stream(values())
                .filter(tf -> tf.name().equalsIgnoreCase(code))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid timeframe code: " + code));
    }
}