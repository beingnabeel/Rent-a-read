package Com.Bookinstein_user_service_demo.dto.request;

import Com.Bookinstein_user_service_demo.enums.AddressType;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DefaultAddressBody {
    private AddressType addressType;
    private String addressId;
}

