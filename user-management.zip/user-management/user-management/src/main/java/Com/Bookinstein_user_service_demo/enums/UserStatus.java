package Com.Bookinstein_user_service_demo.enums;

public enum UserStatus
{
    ACTIVE,
    INACTIVE
}
