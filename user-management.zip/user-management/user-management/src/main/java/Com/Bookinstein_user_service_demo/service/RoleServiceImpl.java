package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.dto.request.AddRole;
import Com.Bookinstein_user_service_demo.dto.request.PermissionRequest;
import Com.Bookinstein_user_service_demo.dto.request.RolePermissionRequest;
import Com.Bookinstein_user_service_demo.entities.Permission;
import Com.Bookinstein_user_service_demo.entities.RoleEntity;
import Com.Bookinstein_user_service_demo.entities.RolePermission;
import Com.Bookinstein_user_service_demo.entities.UserRole;
import Com.Bookinstein_user_service_demo.enums.Role;
import Com.Bookinstein_user_service_demo.exception.DuplicatePermissionException;
import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
import Com.Bookinstein_user_service_demo.repository.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
public class RoleServiceImpl implements RoleService {

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private RolePermissionRepository rolePermissionRepository;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private PermissionRepository permissionRepository;

    @Override
    public RoleEntity createRole(AddRole roleRequest) {
        try {
            Role roleName = roleRequest.getRoleName();

            if (roleRepository.existsByRoleName(roleName.name())) {
                throw new IllegalArgumentException("Role " + roleName + " already exists in the database.");
            }

            RoleEntity roleEntity = new RoleEntity();
            roleEntity.setRoleName(roleName.name());
            roleEntity.setCreatedAt(java.time.Instant.now());
            roleEntity.setUpdatedAt(java.time.Instant.now());

            RoleEntity savedRole = roleRepository.save(roleEntity);

            log.info("Role created successfully: {}", savedRole);
            return savedRole;
        } catch (IllegalArgumentException e) {
            log.error("Validation error: {}", e.getMessage());
            throw e;
        } catch (Exception e) {
            log.error("An unexpected error occurred while creating the role: {}", e.getMessage());
            throw new RuntimeException("Error while creating role", e);
        }
    }

    public List<RoleEntity> getAllRoles() {
        return roleRepository.findAll();
    }

    public RoleEntity getRoleById(String id) {
        return roleRepository.findById(id).orElseThrow(() -> new RuntimeException("Role not found"));
    }

    public RoleEntity updateRole(String id, AddRole updatedRole) {
        RoleEntity role = getRoleById(id);
        role.setRoleName(String.valueOf(updatedRole.getRoleName()));
        role.setUpdatedAt(java.time.Instant.now());
        return roleRepository.save(role);
    }

    @Operation(summary = "Delete Role", description = "The endpoint will delete role")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Operation Successful")
    })

    @Transactional
    public void deleteRole(String roleId) {
        userRoleRepository.deleteByRoleId(roleId);
        rolePermissionRepository.deleteByRoleId(roleId);
        roleRepository.deleteById(roleId);
    }

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Override
    public void assignRoleToUser(String userId, String roleId) {
        UserRole userRole = new UserRole();
        userRole.setUserId(userId);
        userRole.setRoleId(roleId);
        userRole.setCreatedAt(java.time.Instant.now());
        userRole.setUpdatedAt(java.time.Instant.now());
        userRoleRepository.save(userRole);
    }


    @Override
    public List<RoleEntity> getRolesByUserId(String userId) {
        if (!isUserExists(userId)) {
            throw new UserNotFoundException("User with ID " + userId + " does not exist.");
        }

        List<UserRole> userRoles = userRoleRepository.findByUserId(userId);
        List<String> roleIds = userRoles.stream()
                .map(UserRole::getRoleId)
                .collect(Collectors.toList());

        return roleRepository.findByIdIn(roleIds);
    }

    private boolean isUserExists(String userId) {
        return userRepo.existsById(userId);
    }

}
