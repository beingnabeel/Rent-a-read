package Com.Bookinstein_user_service_demo.enums;

public enum UserType {
    LIBRARY,
    ONLINE_CLASS
}
