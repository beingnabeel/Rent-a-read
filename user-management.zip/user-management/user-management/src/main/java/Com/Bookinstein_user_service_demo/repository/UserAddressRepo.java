package Com.Bookinstein_user_service_demo.repository;

import Com.Bookinstein_user_service_demo.entities.UserAddressEntity;
import Com.Bookinstein_user_service_demo.entities.UserProfile;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserAddressRepo extends MongoRepository<UserAddressEntity, String> {
    Page<UserAddressEntity> findAllByUserId(String id, Pageable pageable);

    boolean existsByIdAndUserId(String addressId, String id);

    Optional<UserAddressEntity> findByIdAndUserId(String addressId, String userId);

    List<UserAddressEntity> findByUserId(String userId);

    Optional<UserAddressEntity> findByUserIdAndIsDefaultTrue(String id);

   // Optional<UserAddressEntity> findByIdAndUserIdAndIsDeletedFalse(String addressId, String userId);

    Optional<UserAddressEntity> findByUserIdAndIsDefault(String userId, boolean b);

    Optional<UserAddressEntity> findByIdAndIsDeletedFalse(String addressId);
}
