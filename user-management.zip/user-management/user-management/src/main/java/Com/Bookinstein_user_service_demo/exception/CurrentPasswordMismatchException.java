package Com.Bookinstein_user_service_demo.exception;

public class CurrentPasswordMismatchException extends RuntimeException {
    public CurrentPasswordMismatchException(String message) {
        super(message);
    }
}
