package Com.Bookinstein_user_service_demo.config;

import Com.Bookinstein_user_service_demo.exception.WriteResponseException;
import Com.Bookinstein_user_service_demo.service.JwtService;
import Com.Bookinstein_user_service_demo.service.TokenCacheService;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.security.SignatureException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;
    private final TokenCacheService tokenCacheService;
    private static final String[] WHITELIST_URL={
            "/auth/**",
            "/v2/api-docs",
            "/v3/api-docs",
            "/v3/api-docs/**",
            "/swagger-resources",
            "/swagger-resources/**",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-ui/**",
            "/webjars/**",
            "/swagger-ui.html",
            "/users/refresh-token",
            "/roles/**",
            "/permissions/**"
    };

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        if (isWhitelisted(request)) {
            filterChain.doFilter(request, response);
            return;
        }
        final String authHeader = request.getHeader("Authorization");

        final String jwt;
        final String userEmail;
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            response.setContentType("application/json");
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            try {
                response.getWriter().write("{\"message\": \"Authentication Token is missing.\"}");
                return;
            } catch (IOException ex) {
                throw new WriteResponseException("Failed to write response", ex);
            }
        }
        jwt = authHeader.substring(7);
        try {
            userEmail = jwtService.extractUsername(jwt);
            if (userEmail != null && SecurityContextHolder.getContext().getAuthentication() == null) {
                UserDetails userDetails = userDetailsService.loadUserByUsername(userEmail);

                if (jwtService.isTokenValid(jwt, userDetails)) {
                    List<GrantedAuthority> authorities = new ArrayList<>();
                    
                    String role = (String) jwtService.extractClaims(jwt,"role");
                    authorities.add(new SimpleGrantedAuthority("ROLE_"+role));

                    List<String> permission = (List<String>) jwtService.extractClaims(jwt,"permissions");
                    if(!permission.isEmpty())
                    {
                        permission.forEach(p->authorities.add(new SimpleGrantedAuthority(p)));
                    }
                    UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                            userDetails, null, authorities);
                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                    SecurityContextHolder.getContext().setAuthentication(authToken);
                    System.out.println(authToken.getAuthorities());
                }
            }
            }catch(ExpiredJwtException ex){
                sendErrorResponse(response, "Token is expired");
                return;
            } catch(SignatureException | MalformedJwtException ex){
                sendErrorResponse(response, "Invalid token");
                return;
            }
        boolean isValidToken = tokenCacheService.isValidToken(jwt);
        if (!isValidToken) {
            sendErrorResponse(response, "Invalid token or token expired. Please login again.");
            return;
        }
        boolean isRefreshTokenValid = tokenCacheService.isValidRefreshToken(jwt);
        if (isRefreshTokenValid) {
            sendErrorResponse(response, "Invalid access token");
            return;
        }
            filterChain.doFilter(request, response);
        }
    private void sendErrorResponse(HttpServletResponse response, String message) throws IOException {
        Map<String, Object> data = new HashMap<>();
        data.put("status", HttpServletResponse.SC_UNAUTHORIZED);
        data.put("error", "Unauthorized");
        data.put("message", message);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.getOutputStream().println(objectMapper.writeValueAsString(data));
    }
    private boolean isWhitelisted(HttpServletRequest request) {
        String path = request.getRequestURI();
        return Arrays.stream(WHITELIST_URL)
                .anyMatch(whiteListUrl -> {
                    if (whiteListUrl.endsWith("/**")) {
                        String urlWithoutWildcard = whiteListUrl.substring(0, whiteListUrl.length() - 3);
                        return path.startsWith(urlWithoutWildcard);
                    } else {
                        return path.equals(whiteListUrl);
                    }
                });
    }
}


