package Com.Bookinstein_user_service_demo.mapper;

import Com.Bookinstein_user_service_demo.dto.request.UserAddressBody;
import Com.Bookinstein_user_service_demo.dto.response.UserAddress;
import Com.Bookinstein_user_service_demo.entities.UserAddressEntity;
import org.mapstruct.Mapper;

@Mapper
public interface UserAddressMapper {
    UserAddressEntity addUserAddressBodyToUserAddressEntity(UserAddressBody userAddressBody);

    UserAddress userAddressEntityToUserAddress(UserAddressEntity addressEntity);
}
