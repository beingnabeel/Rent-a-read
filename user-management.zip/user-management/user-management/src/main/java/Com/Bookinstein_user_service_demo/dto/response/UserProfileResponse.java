package Com.Bookinstein_user_service_demo.dto.response;

import Com.Bookinstein_user_service_demo.enums.UserProfileStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserProfileResponse {
    private String id;
    private String userId;
    private String fullName;
    private String email;
    private String phoneNumber;
//    private LocalDate dob;
    private int age;
    private String schoolId;
    private String schoolName;
    private String classAndSection;
    private String adminComment;
    private String profileImageUrl;
    private UserProfileStatus status;
    private String defaultAddressType;
    private String defaultAddressId;
    @CreatedDate
    private String createdAt;
    @LastModifiedDate
    private String createdBy;
    private String updatedAt;
    @LastModifiedDate
    private String updatedBy;
    private boolean isDefault;

}
