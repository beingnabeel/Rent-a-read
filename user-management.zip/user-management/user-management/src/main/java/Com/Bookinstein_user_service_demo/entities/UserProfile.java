package Com.Bookinstein_user_service_demo.entities;

import Com.Bookinstein_user_service_demo.enums.AddressType;
import Com.Bookinstein_user_service_demo.enums.UserProfileStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;
import org.w3.x2000.x09.xmldsig.ObjectType;

import java.time.Instant;
import java.time.LocalDate;

@Getter
@Setter
@Document(collection = "UserProfiles")
@AllArgsConstructor
@NoArgsConstructor
public class UserProfile {
        @Id
        private String profileId;
        @Field(targetType = FieldType.OBJECT_ID)
        private String userId;
        private String firstName;
        private String lastName;
        private String email;
        @Field(targetType = FieldType.OBJECT_ID)
        private String schoolId;
        private String schoolName;
        private String profileImageUrl;
        private LocalDate DateOfBirth;
        private Integer age;
        private boolean isDefault=Boolean.FALSE;
        private String classAndSection;
        @Field(targetType = FieldType.STRING)
        private AddressType defaultAddressType;
        private String defaultAddressId;
        private UserProfileStatus status;
        @CreatedDate
        private Instant createdAt;
        @CreatedBy
        private String createdBy;
        @LastModifiedDate
        private Instant updatedAt;
        @LastModifiedBy
        private String updatedBy;
        private String adminComment;
        private String PhoneNumber;

}


