package Com.Bookinstein_user_service_demo.controller;

import Com.Bookinstein_user_service_demo.dto.request.ForgotPasswordRequest;
import Com.Bookinstein_user_service_demo.dto.request.LoginRequest;
import Com.Bookinstein_user_service_demo.dto.request.ResetPasswordRequest;
import Com.Bookinstein_user_service_demo.dto.request.UserRequestBody;
import Com.Bookinstein_user_service_demo.dto.response.LoginResponse;
import Com.Bookinstein_user_service_demo.dto.response.SuccessPasswordResponse;
import Com.Bookinstein_user_service_demo.dto.response.SuccessResponse;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import Com.Bookinstein_user_service_demo.service.AuthenticationService;
import Com.Bookinstein_user_service_demo.service.JwtService;
import Com.Bookinstein_user_service_demo.service.PasswordForgotService;
import Com.Bookinstein_user_service_demo.service.TokenCacheService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.*;


@RestController
@Slf4j
@RequiredArgsConstructor
@SecurityRequirement(name = "Authorization")
@CrossOrigin("**")
@RequestMapping("/auth")
public class AuthenticationController
{
    private final JwtService jwtService;
    private final AuthenticationService authenticationService;
    private final PasswordForgotService passwordResetService;
    private final TokenCacheService tokenCacheService;
    private final UserRepo userRepo;
    @Autowired
    private UserDetailsService userDetailsService;



    @PostMapping("/signup")
    @ResponseStatus(HttpStatus.CREATED)
    public SuccessResponse createUser(@Valid @RequestBody UserRequestBody userRequestBody)
    {
          return authenticationService.createUser(userRequestBody);

    }
    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest loginRequest) {
        return authenticationService.authenticate(loginRequest);
    }

    @PostMapping("/forgot-password")
    public SuccessPasswordResponse forgotPassword(@RequestBody ForgotPasswordRequest request) {
        passwordResetService.sendResetPasswordLink(request.getEmail());
        return new SuccessPasswordResponse("Password reset link has been sent to your email.");
    }

    @PostMapping("/reset-password")
    public SuccessPasswordResponse resetPassword(@RequestParam String token, @RequestBody ResetPasswordRequest request) {
        passwordResetService.resetPassword(token, request.getNewPassword(), request.getConfirmPassword());
        return new SuccessPasswordResponse("Password reset successful.");
    }
    @GetMapping("/validate")
    public boolean isValidToken(String token){
        return tokenCacheService.isValidToken(token);
    }

}
