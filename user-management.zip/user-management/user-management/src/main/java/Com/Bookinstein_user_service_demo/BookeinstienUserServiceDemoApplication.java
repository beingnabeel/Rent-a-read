package Com.Bookinstein_user_service_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class BookeinstienUserServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookeinstienUserServiceDemoApplication.class, args);
	}

}
