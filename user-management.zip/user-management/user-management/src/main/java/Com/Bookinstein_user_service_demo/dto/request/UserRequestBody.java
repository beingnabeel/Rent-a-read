package Com.Bookinstein_user_service_demo.dto.request;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserRequestBody {
    @NotBlank(message = "must req")
    @Pattern(regexp = "^[A-Z][a-zA-Z]*$", message = "Username must start with a capital letter and contain only alphabetic characters")
    private String firstName;
    @NotBlank
    @Pattern(regexp = "^[A-Z][a-zA-Z]*$", message = "Username must start with a capital letter and contain only alphabetic characters")
    private String lastName;
    @Email
    @NotBlank(message = "Only accept the email and not black")
    private String email;
    @NotBlank
    @Pattern(regexp = "^[0-9]{10}$", message = "Mobile number must be exactly 10 digits")
    private String phoneNo;
    private String schoolId;
    @Past(message = "Date of birth must be in the past")
    @NotNull(message = "accept the date like 2024-05-30")
    private LocalDate dateOfBirth;
    @NotBlank
    @Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{4,12}$",
            message = "password must be min 4 and max 12 length containing atleast 1 uppercase, 1 lowercase, 1 special character and 1 digit ")
    private String password;
    private String classAndSection;
}
