package Com.Bookinstein_user_service_demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.auditing.DateTimeProvider;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.mongodb.config.EnableMongoAuditing;

import java.time.LocalDateTime;
import java.util.Optional;

@Configuration
@EnableMongoAuditing(dateTimeProviderRef = "utcDateTimeProvider", auditorAwareRef = "auditorProvider")
public class MongoAuditConfig {
    @Bean
    public DateTimeProvider utcDateTimeProvider() {
        return () -> Optional.of(LocalDateTime.now());
    }

    @Bean
    public AuditorAware<String> auditorProvider() {
        return new AuditorAware<String>() {
            @Override
            public Optional<String> getCurrentAuditor() {
               return Optional.empty();
            }
        };
    }

//    @Bean
//    public AuditorAware<Integer> auditorProvider() {
//        return new AuditorAware<Integer>() {
//            @Override
//            public Optional<Integer> getCurrentAuditor() {
//                return Optional.empty();
//            }
//        };
//    }
}