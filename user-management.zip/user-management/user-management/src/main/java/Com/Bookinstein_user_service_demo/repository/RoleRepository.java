package Com.Bookinstein_user_service_demo.repository;

import Com.Bookinstein_user_service_demo.entities.RoleEntity;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface RoleRepository extends MongoRepository<RoleEntity, String> {
    boolean existsByRoleName(String name);

    List<RoleEntity> findByIdIn(List<String> roleIds);
    Optional<RoleEntity> findByRoleName(String roleName);
}