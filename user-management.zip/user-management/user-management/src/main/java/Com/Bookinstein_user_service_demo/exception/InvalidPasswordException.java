package Com.Bookinstein_user_service_demo.exception;

public class InvalidPasswordException extends RuntimeException {
    public InvalidPasswordException(String message) {
        super("Invalid Password: " + message);
    }
}
