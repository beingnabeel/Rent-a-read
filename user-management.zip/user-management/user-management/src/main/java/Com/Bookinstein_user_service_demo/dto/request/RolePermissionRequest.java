package Com.Bookinstein_user_service_demo.dto.request;

import lombok.Getter;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
public class RolePermissionRequest {
    Set<String> permissionIds;
}
