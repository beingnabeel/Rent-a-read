package Com.Bookinstein_user_service_demo.dto.response;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SuccessAddressResponse {
    private String message;
}
