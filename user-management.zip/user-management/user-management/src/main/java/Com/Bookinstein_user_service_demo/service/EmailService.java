//package Com.Bookinstein_user_service_demo.service;
//
//import Com.Bookinstein_user_service_demo.entities.User;
//import Com.Bookinstein_user_service_demo.repository.UserRepo;
//import jakarta.mail.MessagingException;
//import jakarta.mail.internet.MimeMessage;
//import org.springframework.mail.SimpleMailMessage;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDateTime;
//import java.util.UUID;
//
//@Service
//public class EmailService {
//
//    private final JavaMailSender mailSender;
//    private final UserRepo userRepo;
//
//    // Injecting JavaMailSender, which is provided by EmailConfig
//    public EmailService(JavaMailSender mailSender, UserRepo userRepo) {
//        this.mailSender = mailSender;
//        this.userRepo = userRepo;
//    }
//
//    /**
//     * Sends an email to the specified recipient.
//     *
//     * @param to      The recipient's email address.
//     * @param subject The subject of the email.
//     * @param message The body of the email.
//     */
//    public void sendEmail(String to, String subject, String message) {
//        try {
//            SimpleMailMessage mailMessage = new SimpleMailMessage();
//            mailMessage.setTo(to);
//            mailMessage.setSubject(subject);
//            mailMessage.setText(message);
//            mailMessage.setFrom("swetakumari633564@gmail.com"); // This can be configured in your EmailConfig
//
//            mailSender.send(mailMessage);
//        } catch (Exception e) {
//            throw new IllegalStateException("Failed to send email", e);
//        }
//    }
//
//
////    public void sendPasswordResetLink(String email) {
////        // Find user by email
////        User user = userRepo.findByEmail(email)
////                .orElseThrow(() -> new RuntimeException("User not found"));
////
////        // Generate reset token
////        String token = UUID.randomUUID().toString();
////        user.setResetToken(token);
////        user.setTokenExpiry(LocalDateTime.now().plusMinutes(30)); // Token valid for 30 minutes
////        userRepo.save(user);
////
////        // Create reset link
////        String resetLink = "http://localhost:8080/auth/reset-password?token=" + token;
////
////        // Send email
////        sendEmail(user.getEmail(), "Password Reset Request", "Click the link to reset your password: " + resetLink);
////    }
//
////    private void sendEmail(String to, String subject, String body) {
////        try {
////            MimeMessage message = mailSender.createMimeMessage();
////            MimeMessageHelper helper = new MimeMessageHelper(message);
////
////            helper.setTo(to);
////            helper.setSubject(subject);
////            helper.setText(body, true); // Set 'true' for HTML content
////
////            mailSender.send(message);
////        } catch (MessagingException ex) {
////            throw new RuntimeException("Failed to send email", ex);
////        }
////    }
//}
