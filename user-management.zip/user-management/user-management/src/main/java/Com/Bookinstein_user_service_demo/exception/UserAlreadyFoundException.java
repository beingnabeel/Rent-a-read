package Com.Bookinstein_user_service_demo.exception;

public class UserAlreadyFoundException extends RuntimeException {
        public UserAlreadyFoundException(String message) {
            super(message);
    }
}
