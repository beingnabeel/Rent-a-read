package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.exception.PasswordMismatchException;
import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class PasswordForgotService {

    private final JavaMailSender mailSender;
    private final UserRepo userRepo;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Autowired
    public PasswordForgotService(UserRepo userRepo,
                                 JavaMailSender mailSender,
                                 PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.userRepo = userRepo;
        this.mailSender = mailSender;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public String generateResetToken(String email) {
        return jwtService.generateResetToken(email);
    }

    public void sendResetPasswordLink(String email) {

        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found"));


        String token = generateResetToken(user.getEmail());
        user.setResetToken(token);
        user.setTokenExpiry(LocalDateTime.now().plusMinutes(10));
        userRepo.save(user);

        String resetLink = "http://localhost:3000/reset-password?token=" + token;
        System.out.println(token);

        sendEmail(user.getEmail(), "Password Reset", "Click here to reset your password: " + resetLink);
    }

    private void sendEmail(String to, String subject, String body) {
        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message);
            helper.setTo(to);
            helper.setSubject(subject);
            helper.setText(body, true);

            mailSender.send(message);
        } catch (Exception e) {
            throw new RuntimeException("Error sending email", e);
        }
    }


    public void resetPassword(String token, String newPassword, String confirmPassword) {

        if (!newPassword.equals(confirmPassword)) {
            throw new PasswordMismatchException("New password and confirm password do not match");
        }

        String email = jwtService.extractUsername(token);

        User user = userRepo.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("Invalid or expired token"));

        if (user.getTokenExpiry().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token has expired");
        }
        user.setPassword(passwordEncoder.encode(newPassword));
        user.setResetToken(null);
        user.setTokenExpiry(null);
        userRepo.save(user);

    }
}