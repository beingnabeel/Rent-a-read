package Com.Bookinstein_user_service_demo.entities;

import lombok.Getter;
import lombok.Setter;
import java.time.Instant;
import java.util.List;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Getter
@Setter
@Document(collection = "RolePermission")
public class RolePermission {
    @Id
    private String id;
    private Set<String> permissionIds;
    private String roleId;
    private Instant createdAt;
    private Instant UpdatedAt;

}
