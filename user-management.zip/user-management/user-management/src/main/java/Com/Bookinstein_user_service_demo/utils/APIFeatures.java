package Com.Bookinstein_user_service_demo.utils;


import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationOperation;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class APIFeatures {
    private Query query;
    private Map<String, String> queryString;
    private List<AggregationOperation> aggregationOperations = new ArrayList<>();

    public APIFeatures(Query query, Map<String, String> queryString) {
        this.query = query;
        this.queryString = queryString;
    }

    public APIFeatures filter() {
        List<String> excludedFields = List.of("page", "sort", "limit", "fields", "search");
        queryString.entrySet().stream()
                .filter(entry -> !excludedFields.contains(entry.getKey()))
                .forEach(entry -> query.addCriteria(Criteria.where(entry.getKey()).is(entry.getValue())));
        return this;
    }

    public APIFeatures search() {
        String searchKey = queryString.get("search");
        if (StringUtils.hasText(searchKey)) {
            String regex = ".*" + searchKey + ".*";
            Criteria searchCriteria = new Criteria().orOperator(
                    Criteria.where("firstName").regex(regex, "i"),
                    Criteria.where("lastName").regex(regex, "i"),
                    Criteria.where("email").regex(regex, "i"),
                    Criteria.where("phoneNo").regex(regex, "i")
            );
            query.addCriteria(searchCriteria);
        }
        return this;
    }

//    public APIFeatures addRoleLookup() {
//        aggregationOperations.add(Aggregation.lookup("userRole", "_id", "userId", "userRole"));
//        aggregationOperations.add(Aggregation.lookup("roles", "userRole.roleId", "_id", "roles"));
//        return this;
//    }

    public APIFeatures projectFields() {
        aggregationOperations.add(Aggregation.project("firstName", "lastName", "email", "phoneNo")
               .and("roles.roleName").as("roles"));
        return this;
    }

    public APIFeatures sort() {
        String sortKey = queryString.get("sort");
        if (StringUtils.hasText(sortKey)) {
            String[] fields = sortKey.split(",");
            for (String field : fields) {
                if (field.startsWith("-")) {
                    query.with(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC, field.substring(1)));
                } else {
                    query.with(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.ASC, field));
                }
            }
        } else {
            query.with(org.springframework.data.domain.Sort.by(org.springframework.data.domain.Sort.Direction.DESC, "createdAt"));
        }
        return this;
    }

    public APIFeatures limitFields() {
        String fields = queryString.get("fields");
        if (StringUtils.hasText(fields)) {
            for (String field : fields.split(",")) {
                query.fields().include(field);
            }
        } else {
            query.fields().exclude("__v");
        }
        return this;
    }

    public APIFeatures paginate() {
        int page = queryString.containsKey("page") ? Integer.parseInt(queryString.get("page")) : 1;
        int limit = queryString.containsKey("limit") ? Integer.parseInt(queryString.get("limit")) : 10;
        int skip = (page - 1) * limit;

        query.skip(skip).limit(limit);
        return this;
    }

    public List<AggregationOperation> getAggregationOperations() {
        return aggregationOperations;
    }

    public APIFeatures roleFilter() {
        String roleName = queryString.get("roleName");

        if (StringUtils.hasText(roleName)) {
            System.out.println("Filtering by role: " + roleName);

            // Lookup to join the 'userRole' collection to get the roles of users
            aggregationOperations.add(Aggregation.lookup("userRole", "_id", "userId", "userRoles"));

            // Lookup to join the 'roles' collection to get the role details using roleId
            aggregationOperations.add(Aggregation.lookup("roles", "userRoles.roleId", "_id", "roles"));

            // Unwind the 'roles' array to access the individual roles for matching
            aggregationOperations.add(Aggregation.unwind("roles"));

            // Match based on the roleName
            aggregationOperations.add(Aggregation.match(Criteria.where("roles.roleName").regex(roleName, "i")));

            System.out.println("Aggregation operations after role filter: " + aggregationOperations);
        }

        return this;
    }

    public Query getQuery() {
        return query;
    }
}