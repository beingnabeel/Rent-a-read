package Com.Bookinstein_user_service_demo.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserWithProfilesResponse {
    private String  id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNo;
    private String schoolId;
    private LocalDate dateOfBirth;
    private String password;
    private boolean emailVerified;
    private boolean phoneNumberVerified;
    private String userType;
    private boolean libraryUser;
    private boolean classUser;
    private String role;
    private List<UserProfileResponse> userProfileResponses;
}
