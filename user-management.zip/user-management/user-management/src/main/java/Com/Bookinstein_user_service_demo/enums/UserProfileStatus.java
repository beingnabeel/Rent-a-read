package Com.Bookinstein_user_service_demo.enums;

public enum UserProfileStatus {
    INACTIVE, ACTIVE,
//        ACTIVE_PENDING,
//        ACTIVE_APROVED,
//        ÁCTIVE_REJECTED
    }


