package Com.Bookinstein_user_service_demo.enums;

public enum Role {
    STUDENT,
    SCHOOL_ADMIN,
    ADMIN, TEACHER;

}
