package Com.Bookinstein_user_service_demo.dto.request;

import Com.Bookinstein_user_service_demo.enums.Role;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;
import java.util.Set;

@Getter
@Setter
public class AddRole {
    @NotNull(message = "Role is required")
    private Role roleName;
    private Instant createdAt;
    private Instant updatedAt;

}
