//package Com.Bookinstein_user_service_demo.controller;
//
//import Com.Bookinstein_user_service_demo.dto.request.UpdateBody;
//import Com.Bookinstein_user_service_demo.dto.request.UserProfilesBody;
//import Com.Bookinstein_user_service_demo.dto.response.FileResponse;
//import Com.Bookinstein_user_service_demo.dto.response.SuccessResponse;
//import Com.Bookinstein_user_service_demo.dto.response.UserResponse;
//import Com.Bookinstein_user_service_demo.entities.UserProfile;
//import Com.Bookinstein_user_service_demo.entities.User;
//import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
//import Com.Bookinstein_user_service_demo.service.UserRegistrationService;
//import jakarta.validation.Valid;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.http.HttpStatus;
//import org.springframework.web.bind.annotation.*;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.io.IOException;
//import java.util.List;
//
//@RestController
//@RequestMapping("/profiles")
//public class UserProfileController
//{
//    @Autowired
//    private final UserRegistrationService userService;
//
////    public UserProfileController(UserRegistrationService userService) {
//        this.userService = userService;
//    }
//
//    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
//    /* User Profiles Body */
//
//    //@PostMapping(value = {"/{id}/profiles", "/profiles"})
//    @PostMapping
//    @ResponseStatus(HttpStatus.CREATED)
//    public SuccessResponse addUserProfiles(@PathVariable(value = "id", required = false) String uid,
//                                           @Valid @RequestBody UserProfilesBody userProfiles) {
//        // return userService.addUserProfiles(uid, userProfiles);
//        return userService.addUserProfiles(userProfiles);
//    }
//    @GetMapping
//    public SuccessResponse getAllUserProfiles() {
//        List<UserResponse> allUsers = userService.getAllUserProfiles();
//
//        if (allUsers.isEmpty()) {
//            throw new UserNotFoundException("No users found.");
//        }
//
//        return SuccessResponse.builder()
//                .message("All users retrieved successfully")
//                .body(allUsers)
//                .build();
//    }
//    @GetMapping("/{id}")
//    public SuccessResponse getUserProfileById(@PathVariable String id) {
//        return userService.getUserProfileById(id);
//    }
//    @PutMapping("/{id}")
//    public SuccessResponse updateUserProfiles(@PathVariable String id, @RequestBody UserProfilesBody userProfilesBody) {
//        logger.info("Update by Id API is executing for user id: {}", id);
//        return userService.updateUserProfiles(id, userProfilesBody);
//    }
//
////    @GetMapping("/all")
////    public List<UserResponse> getAllUsersWithProfiles() {
////        return userService.getAllUsersWithProfiles();
////    }
//
//
//    @Value("${project.image}")
//    private String path;
//
//    @PostMapping("/upload")
//    public FileResponse uploadImage(@RequestParam("images") MultipartFile images) throws IOException {
//
//        String fileName = null;
//        try {
//
//            fileName = this.userService.uploadImage(path, images);
//        } catch (IOException ex) {
//            ex.printStackTrace();
//            return new FileResponse(fileName, "Images not uploaded: " + ex.getMessage());
//        }
//
//        return new FileResponse(fileName, "Image successfully uploaded");
//    }
//
//    @DeleteMapping("/delete/{fileName}")
//    public FileResponse deleteImage(@PathVariable String fileName) throws IOException {
//
//        String message = userService.deleteImage(path, fileName);
//
//        return new FileResponse(fileName, message);
//    }
//    @GetMapping("/{profileId}/users/{userId}")
//    public UserProfile getUserProfileByUserIdAndProfileId(@PathVariable String userId, @PathVariable String profileId) {
//        return userService.getUserProfileByUserIdAndProfileId(userId, profileId);
//    }
//
//    @PutMapping("/{profileId}/users/{userId}")
//    public User updateUserAndProfile(@PathVariable String userId,
//                                      @PathVariable String profileId,
//                                      @RequestBody UpdateBody updatedBody) {
//        return userService.updateUserAndProfile(userId, profileId, updatedBody);
//    }
//}
//
//
//
