//package Com.Bookinstein_user_service_demo.service;
//
//import Com.Bookinstein_user_service_demo.dto.request.ForgotPasswordOtpRequest;
//import Com.Bookinstein_user_service_demo.dto.request.OtpRequest;
//import Com.Bookinstein_user_service_demo.dto.response.ForgotPasswordResponse;
//import Com.Bookinstein_user_service_demo.dto.response.ResetPasswordResponse;
//import Com.Bookinstein_user_service_demo.entities.User;
//import Com.Bookinstein_user_service_demo.repository.UserRepo;
//import jakarta.mail.MessagingException;
//import jakarta.mail.internet.MimeMessage;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.mail.javamail.JavaMailSender;
//import org.springframework.mail.javamail.MimeMessageHelper;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import java.time.LocalDateTime;
//import java.util.Optional;
//import java.util.Random;
//
//@Service
//@Slf4j
//public class ForgotPasswordService {
//    @Autowired
//    private BCryptPasswordEncoder passwordEncoder;
//
//    private final UserRepo userRepo;
//    private final JavaMailSender mailSender;
//
//    public ForgotPasswordService(UserRepo userRepo, JavaMailSender mailSender) {
//        this.userRepo = userRepo;
//        this.mailSender = mailSender;
//    }
//
//    // Send OTP to user's email
//    public ForgotPasswordResponse sendOtp(OtpRequest request) {
//        Optional<User> userOptional = userRepo.findByEmail(request.getEmail());
//
//        if (userOptional.isEmpty()) {
//            return new ForgotPasswordResponse("No user found with this email");
//        }
//
//        User user = userOptional.get();
//
//        String otp = String.valueOf(1000 + new Random().nextInt(9000));
//        user.setResetToken(otp);
//        user.setTokenExpiry(LocalDateTime.now().plusMinutes(10));
//        userRepo.save(user);
//
//        // Send OTP via email
//        sendEmail(user.getEmail(), "Your OTP for Password Reset", "Your OTP is: " + otp);
//
//        return new ForgotPasswordResponse("OTP sent to your email");
//    }
//
//    // Validate OTP and update password
//    public ResetPasswordResponse verifyOtpAndUpdatePassword(ForgotPasswordOtpRequest request) {
//        Optional<User> userOptional = userRepo.findByResetToken(request.getOtp());
//
//       // if (userOptional.isEmpty() || !userOptional.getOtp().equals(request.getOtp())) {
//        if (userOptional.isEmpty()){
//            throw new RuntimeException("Invalid OTP");
//        }
//
//        User user = userOptional.get();
//
//        if (user.getTokenExpiry().isBefore(LocalDateTime.now())) {
//            throw new RuntimeException("OTP has expired");
//        }
//
//        // Update password
//        user.setPassword(passwordEncoder.encode(request.getNewPassword()));  // Encrypt password
//        user.setResetToken(null);  // Clear OTP
//        user.setTokenExpiry(null);  // Clear expiry time
//        userRepo.save(user);
//
//        return new ResetPasswordResponse("Password updated successfully");
//    }
//
//    // Helper method to send email
//    private void sendEmail(String to, String subject, String body) {
//        MimeMessage message = mailSender.createMimeMessage();
//        MimeMessageHelper helper = new MimeMessageHelper(message);
//
//        try {
//            helper.setTo(to);
//            helper.setSubject(subject);
//            helper.setText(body);
//            helper.setFrom("swetakumari633564@gmail.com"); // Sender email
//            System.out.println("sent email");
//
//            mailSender.send(message);
//            System.out.println("after sending");
//        } catch (MessagingException ex) {
//            // Log the exception for debugging
//            log.error("Error sending email", ex);
//            throw new RuntimeException("Error sending email", ex);  // Handle as needed
//        }
//    }
//}