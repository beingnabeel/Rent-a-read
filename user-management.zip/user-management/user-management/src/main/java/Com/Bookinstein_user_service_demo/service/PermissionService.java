package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.dto.request.PermissionRequest;
import Com.Bookinstein_user_service_demo.dto.request.RolePermissionRequest;
import Com.Bookinstein_user_service_demo.entities.Permission;
import jakarta.validation.Valid;

import java.util.List;

public interface PermissionService {
    Permission createPermission(@Valid PermissionRequest permissionRequest);

    List<Permission> getAllPermissions();

    void assignPermissionToRole(String roleId, RolePermissionRequest rolePermission);

    List<Permission> getPermissionsByUserId(String userId);

    List<Permission> getPermissionsByRoleId(String roleId);
}
