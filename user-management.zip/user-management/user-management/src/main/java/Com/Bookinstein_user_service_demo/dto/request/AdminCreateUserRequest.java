package Com.Bookinstein_user_service_demo.dto.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminCreateUserRequest
{
    private String name;
    private String mailTo;
}
