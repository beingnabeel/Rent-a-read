package Com.Bookinstein_user_service_demo.exception;

public class DuplicatePermissionException extends RuntimeException{
    public DuplicatePermissionException(String message) {
        super(message);
    }
}
