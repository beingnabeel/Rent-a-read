package Com.Bookinstein_user_service_demo.dto.request;


import Com.Bookinstein_user_service_demo.enums.UserProfileStatus;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Past;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class UserProfilesBody {

    @NotNull
    @Pattern(regexp = "^[A-Z][a-zA-Z]*$", message = "Username must start with a capital letter and contain only alphabetic characters")
    private String firstName;
    @NotNull
    @Pattern(regexp = "^[A-Z][a-zA-Z]*$", message = "Username must start with a capital letter and contain only alphabetic characters")
    private String lastName;
    private boolean isDefault;
    @Field(targetType = FieldType.OBJECT_ID)
    private String schoolId;
//    @Past(message = "Date of birth must be in the past")
//    @NotNull
    private LocalDate dateOfBirth;
    private String classAndSection;
    private String adminComment;
    private String profileImageUrl;
    private UserProfileStatus status;

}
