//package Com.Bookinstein_user_service_demo.repository;
//
//
//import Com.Bookinstein_user_service_demo.dto.response.NewlyOnboaredUserAndProfileResponse;
//import com.mongodb.client.MongoCollection;
//import com.mongodb.client.MongoDatabase;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.mongodb.core.mapping.Document;
//import org.springframework.stereotype.Repository;
//
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//import java.util.List;
//
//    @Repository
//    public class CustomUserRepository {
//        @Autowired
//        private MongoDatabase mongoDatabase;
//
//        public List<NewlyOnboaredUserAndProfileResponse> getUsersByTimeframe(String status, LocalDateTime startTime, LocalDateTime endTime) {
//            MongoCollection<Document> userCollection = mongoDatabase.getCollection("users");
//
//            List<Document> pipeline = List.of(
//                    new Document("$match", new Document("status", status)
//                            .append("createdAt", new Document("$gte", startTime).append("$lte", endTime))),
//                    new Document("$lookup", new Document("from", "user_roles")
//                            .append("localField", "_id")
//                            .append("foreignField", "userId")
//                            .append("as", "userRoles")),
//                    new Document("$unwind", new Document("path", "$userRoles").append("preserveNullAndEmptyArrays", true)),
//                    new Document("$lookup", new Document("from", "roles")
//                            .append("localField", "userRoles.roleId")
//                            .append("foreignField", "_id")
//                            .append("as", "roleDetails")),
//                    new Document("$unwind", new Document("path", "$roleDetails").append("preserveNullAndEmptyArrays", true)),
//                    new Document("$project", new Document("_id", 0)
//                            .append("userId", "$_id")
//                            .append("fullName", new Document("$concat", List.of("$firstName", " ", "$lastName")))
//                            .append("email", 1)
//                            .append("phoneNo", 1)
//                            .append("status", 1)
//                            .append("createdAt", 1)
//                            .append("updatedAt", 1)
//                            .append("roleName", "$roleDetails.roleName"))
//            );
//
//            List<NewlyOnboaredUserAndProfileResponse> responses = new ArrayList<>();
//            for (Document doc : userCollection.aggregate(pipeline)) {
//                NewlyOnboaredUserAndProfileResponse response = new NewlyOnboaredUserAndProfileResponse();
//                response.setUserId(doc.getString("userId"));
//                response.setFullName(doc.getString("fullName"));
//                response.setEmail(doc.getString("email"));
//                response.setPhoneNo(doc.getString("phoneNo"));
//                response.setStatus(doc.getString("status"));
//                response.setRoleName(doc.getString("roleName"));
//                response.setCreatedAt(doc.getDate("createdAt").toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDateTime());
//                response.setUpdatedAt(doc.getDate("updatedAt").toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDateTime());
//                responses.add(response);
//            }
//
//            return responses;
//        }
//    }
//}
