package Com.Bookinstein_user_service_demo.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
public class EmailConfig {

//    @Bean
//    public JavaMailSender javaMailSender() {
//        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
//        mailSender.setHost("smtp.gmail.com");  // Set SMTP host (for example Gmail)
//        mailSender.setPort(587);  // SMTP port
//        mailSender.setUsername("swetakumari6395@gmail.com");  // Replace with your email
//        mailSender.setPassword("Sweta123@");  // Replace with your email password
//
//        // Additional mail properties (optional, as needed)
//        mailSender.getJavaMailProperties().setProperty("mail.smtp.auth", "true");
//        mailSender.getJavaMailProperties().setProperty("mail.smtp.starttls.enable", "true");
//
//        return mailSender;
//    }

    @Value("${mail.host}")
    private String host;

    @Value("${mail.port}")
    private int port;

    @Value("${mail.username}")
    private String username;

    @Value("${mail.password}")
    private String password;

    @Bean
    public JavaMailSender javaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(host);
        mailSender.setPort(port);
        mailSender.setUsername(username);
        mailSender.setPassword(password);

        // Additional mail properties
        mailSender.getJavaMailProperties().setProperty("mail.smtp.auth", "true");
        mailSender.getJavaMailProperties().setProperty("mail.smtp.starttls.enable", "true");

        return mailSender;
    }
}

