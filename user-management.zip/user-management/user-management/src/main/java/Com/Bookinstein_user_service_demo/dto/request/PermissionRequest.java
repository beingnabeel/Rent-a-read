package Com.Bookinstein_user_service_demo.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

@Getter
@Setter
public class PermissionRequest {
    @NotBlank(message = "permission name is required")
    private String permissionName;
    private Instant createdAt;
    private Instant updatedAt;
}
