package Com.Bookinstein_user_service_demo.mapper;

import Com.Bookinstein_user_service_demo.dto.request.UserRequestBody;
import Com.Bookinstein_user_service_demo.dto.response.UserResponse;
import Com.Bookinstein_user_service_demo.entities.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserAuthenticationMapper
{

    User userRequestBodyToUser(UserRequestBody userRequestBody);

    UserResponse userToUserResponse(User user);
}
