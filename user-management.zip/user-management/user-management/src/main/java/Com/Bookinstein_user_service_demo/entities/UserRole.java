package Com.Bookinstein_user_service_demo.entities;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Document(collection = "userRole")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Getter
@Setter
public class UserRole {
    @Id
    private String id;
    private String userId;
    private String roleId;
    private Instant createdAt;
    private Instant updatedAt;

}
