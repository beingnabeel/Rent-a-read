package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.dto.request.AddRole;
import Com.Bookinstein_user_service_demo.dto.request.PermissionRequest;
import Com.Bookinstein_user_service_demo.dto.request.RolePermissionRequest;
import Com.Bookinstein_user_service_demo.entities.Permission;
import Com.Bookinstein_user_service_demo.entities.RoleEntity;

import java.util.List;

public interface RoleService {

    List<RoleEntity> getAllRoles();

    RoleEntity getRoleById(String id);

    RoleEntity updateRole(String id, AddRole role);

    void deleteRole(String id);

    RoleEntity createRole(AddRole role);

    void assignRoleToUser(String userId, String roleId);

    List<RoleEntity> getRolesByUserId(String userId);

}
