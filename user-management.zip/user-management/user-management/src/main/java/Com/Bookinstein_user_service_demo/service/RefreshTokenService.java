package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.dto.response.LoginResponse;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.exception.ExpiredTokenException;
import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
import Com.Bookinstein_user_service_demo.repository.UserRepo;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RefreshTokenService {

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;
    private final UserRepo userRepo;
    private final TokenCacheService tokenCacheService;

    public RefreshTokenService(JwtService jwtService, UserDetailsService userDetailsService, UserRepo userRepo, TokenCacheService tokenCacheService) {
        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
        this.userRepo = userRepo;
        this.tokenCacheService = tokenCacheService;
    }

    public LoginResponse refreshAccessToken(String refreshToken) {
        try {
            if (jwtService.isTokenExpired(refreshToken)) {
                throw new ExpiredTokenException("Refresh token is expired");
            }
            String userId = jwtService.extractUserId(refreshToken);
            if (!tokenCacheService.isValidRefreshToken(refreshToken)) {
                throw new IllegalArgumentException("Invalid refresh token");
            }
            Optional<User> optionalUser = userRepo.findById(userId);
            User user = optionalUser.get();
            String newAccessToken = jwtService.generateAccessToken(user);
            String newRefreshToken = jwtService.generateRefreshToken(user);

            tokenCacheService.storeTokens(userId, newAccessToken, newRefreshToken);

            LoginResponse loginResponse = new LoginResponse();
            loginResponse.setToken(newAccessToken);
            loginResponse.setExpiresIn(jwtService.getTokenExpiryTime());
            loginResponse.setRefreshToken(newRefreshToken);

            return loginResponse;
        } catch (IllegalArgumentException e) {

            System.err.println("Refresh Token Error: " + e.getMessage());
            throw e;
        } catch (UserNotFoundException e) {

            System.err.println("User not found: " + e.getMessage());
            throw e;
        } catch (Exception e) {

            System.err.println("Unexpected error during refresh token process: " + e.getMessage());
            throw new InternalAuthenticationServiceException("Server error");
        }
    }
}

