package Com.Bookinstein_user_service_demo.entities;


import Com.Bookinstein_user_service_demo.enums.UserStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.*;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.data.mongodb.core.mapping.FieldType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;

@Setter
@Getter
@CompoundIndex(def = "{'resetToken': 1}", unique = true)
@Document(collection = "Users")
public class User implements UserDetails {
    @Id
    private String id;
    private String firstName;
    private String lastName;
    private String email;
    private boolean emailVerified = false;
    private String otp;
    private LocalDateTime otpExpiry;
    private String phoneNo;
    private boolean phoneNoVerified;
    @Field(targetType = FieldType.OBJECT_ID)
    private String schoolId;
    private LocalDate dateOfBirth;
    private String password;
    private String resetToken;
    private LocalDateTime tokenExpiry;
    @Field(targetType = FieldType.STRING)
    @NotNull(message = "Role is required")
    private String roleId;
    @Field(targetType = FieldType.STRING)
    private UserStatus status = UserStatus.ACTIVE;
    private Boolean isDeleted;
    @CreatedDate
    private Instant createdAt;
    @CreatedBy
    private String createdBy;
    @LastModifiedDate
    private Instant updatedAt;
    @LastModifiedBy
    private String updatedBy;

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of();
    }

    @Override
    public String getPassword() {
        return this.password;
    }

    @Override
    public String getUsername() {
        return this.email;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return this.status == UserStatus.ACTIVE;
    }
}

