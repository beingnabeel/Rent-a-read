package Com.Bookinstein_user_service_demo.dto.response;

import Com.Bookinstein_user_service_demo.enums.Role;
import Com.Bookinstein_user_service_demo.enums.UserStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class NewlyOnboardedUser {
    private String userId;
    private String FullName;
    private String email;
    private String mobile;
   // private UserType userType;
    private String roleName;
    private UserStatus status;
    private Instant createdAt;
    private Instant updatedAt;
  //  private List<NewlyOnboardedProfile> userProfileList;
}