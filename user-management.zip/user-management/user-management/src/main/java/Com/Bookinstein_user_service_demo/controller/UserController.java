package Com.Bookinstein_user_service_demo.controller;

import Com.Bookinstein_user_service_demo.Client.SchoolClient;
import Com.Bookinstein_user_service_demo.dto.request.*;
import Com.Bookinstein_user_service_demo.dto.response.*;
import Com.Bookinstein_user_service_demo.entities.RoleEntity;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.entities.UserProfile;
import Com.Bookinstein_user_service_demo.enums.Role;
import Com.Bookinstein_user_service_demo.enums.TimeFrame;
import Com.Bookinstein_user_service_demo.enums.UserProfileStatus;
import Com.Bookinstein_user_service_demo.enums.UserStatus;
import Com.Bookinstein_user_service_demo.exception.ExpiredTokenException;
import Com.Bookinstein_user_service_demo.exception.ImageUploadException;
import Com.Bookinstein_user_service_demo.exception.UnauthorizedException;
import Com.Bookinstein_user_service_demo.exception.UserNotFoundException;
import Com.Bookinstein_user_service_demo.repository.RoleRepository;
import Com.Bookinstein_user_service_demo.service.*;
import Com.Bookinstein_user_service_demo.utils.ExcelExportUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Positive;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/users")
@SecurityRequirement(name = "Authorization")
@RequiredArgsConstructor
@Slf4j
//@CrossOrigin("**")
public class UserController {
    private final UserRegistrationService userService;
    private final JwtService jwtService;
    private final EmailVerificationService emailVerificationService;
    private final TokenCacheService tokenCacheService;
    private final RefreshTokenService refreshTokenService;
    private final SchoolClient schoolClient;

    @Autowired
    public UserController(JwtService jwtService, UserRegistrationService userService, EmailVerificationService emailVerificationService, TokenCacheService tokenCacheService, RefreshTokenService refreshTokenService, SchoolClient schoolClient) {
        this.jwtService = jwtService;
        this.userService = userService;
        this.emailVerificationService = emailVerificationService;
        this.tokenCacheService = tokenCacheService;
        this.refreshTokenService = refreshTokenService;
        this.schoolClient = schoolClient;
    }

    @GetMapping("/me")
    public ResponseEntity<User> authenticatedUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        User currentUser = (User) authentication.getPrincipal();
        return ResponseEntity.ok(currentUser);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Read_Data')")
       @GetMapping()
       public PageResponse<UserResponse> getAllUsers(
        @RequestParam(required = false) UserStatus status,
        @RequestParam(defaultValue = "0") Integer pageNumber,
        @RequestParam(defaultValue = "10") Integer pageSize,
        @RequestParam(required = false) String searchKey) {
      return userService.getAllUsers(status, pageNumber, pageSize, searchKey);
     }

    @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN') and hasAuthority('Read_Data')")
    @GetMapping("/{userId}")
    public UserResponse getUserById(@PathVariable String userId) {
        return userService.getUserById(userId);
    }

    @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Write_Data')")
    @PutMapping("/{userId}")
    public SuccessResponse updateUser(@PathVariable String userId, @Valid @RequestBody UpdateBody updateBody, HttpServletRequest request) {
        return userService.updateUser(userId, updateBody, request);

    }

    @Operation(summary = "Delete User profile",
            description = "The endpoint will delete user.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Operation Successful")
    })
    @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Delete_Data'))")
    @PatchMapping("/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable String userId) {
        userService.deleteUser(userId);
        return ResponseEntity.noContent().build();
    }

    /* User Profiles Body */

    @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Write_Data')")
    @PostMapping("/profiles")
    @ResponseStatus(HttpStatus.CREATED)
    public SuccessResponse addUserProfile(@Valid @RequestBody UserProfilesBody userProfilesBody, HttpServletRequest request) {
        return userService.addUserProfile(userProfilesBody, request);
    }

    @PreAuthorize("(hasRole('ROLE_ADMIN') and hasAuthority('Read_Data'))")
    @GetMapping("/profiles")
    public List<UserAndAllProfilesResponse> getAllUserProfiles() {
        return userService.getAllUserProfiles();
    }


    @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Read_Data')")
    @GetMapping("/{id}/profiles")
    public List<UserProfileResponse> getUserProfiles(@PathVariable("id") String userId,@RequestParam(required = false) boolean isDefault) {
        return userService.getUserProfilesByUserId(userId,isDefault);
    }

    // @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN') and hasAuthority('Read_Data')")

@PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Read_Data')")
    @GetMapping("/profiles/{id}")
    public SuccessResponse getUserProfileById(@PathVariable String id) {
        log.info("Fetching user profile with ID: {}", id);
        return userService.getUserProfileById(id);
    }

    // @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN') and hasAuthority('Write_Data')")

@PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Read_Data')")
    @PutMapping("/profiles/{id}")
    public SuccessResponse updateUserProfiles(@PathVariable String id, @Valid @RequestBody UserProfilesBody userProfilesBody, HttpServletRequest request) {
        return userService.updateUserProfiles(id, userProfilesBody, request);
    }

    @Operation(summary = "Upload profile picture",
            description = "The endpoint will upload profile picture.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Operation Successful")
    })
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT', 'ROLE_SCHOOL_ADMIN')")
    @PostMapping("/upload")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<String> uploadImage(@RequestParam("file") MultipartFile file,HttpServletRequest request) throws IOException {
        String fileName = userService.uploadImage(file,request);
        return ResponseEntity.ok("File uploaded successfully: " + fileName);
    }

    @Operation(summary = "Delete profile picture",
            description = "The endpoint will delete profile picture.")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "204", description = "Operation Successful")
    })
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT', 'ROLE_SCHOOL_ADMIN')")
    @DeleteMapping("/delete/profileImage")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<String> deleteImage(HttpServletRequest request) {
        try {
            String message = userService.deleteImage(request);
            return ResponseEntity.ok(message);
        } catch (ImageUploadException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("An error occurred: " + e.getMessage());
        }
    }

    @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Read_Data')")
    @GetMapping("/{userId}/profiles/{profileId}")
    public UserProfile getUserProfileByUserIdAndProfileId(@PathVariable String userId, @PathVariable String profileId) {
        return userService.getUserProfileByUserIdAndProfileId(userId, profileId);
    }

    @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Write_Data')")
    @PutMapping("/{userId}/profiles/{profileId}")
    public ResponseEntity<User> updateUserAndProfile(
            @PathVariable String userId,
            @PathVariable String profileId,
            @Valid @RequestBody UpdateBody updateBody) {
        User updatedUser = userService.updateUserAndProfile(userId, profileId, updateBody);
        return ResponseEntity.ok(updatedUser);
    }


//    @GetMapping("/search")
//    public ResponseEntity<List<User>> searchUserProfiles(@RequestParam String firstName,
//                                                         @RequestParam(required = false) String lastName) {
//        log.info("Inside controller - searching with firstName: {} and lastName: {}", firstName, lastName);
//
//        try {
//            List<User> users = userService.searchUsers(firstName, lastName);
//            if (users.isEmpty()) {
//                log.warn("No users found with the provided search parameters.");
//                return ResponseEntity.status(HttpStatus.NO_CONTENT).body(users);
//            }
//            return ResponseEntity.ok(users);
//        } catch (Exception e) {
//            log.error("Error occurred during search: ", e);
//            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
//        }
//    }

    @PreAuthorize("(hasRole('ROLE_ADMIN') or hasRole('ROLE_STUDENT') or hasRole('ROLE_SCHOOL_ADMIN')) and hasAuthority('Write_Data')")
    @PostMapping("/email/generate-otp")
    public SuccessPasswordResponse generateOtp(@RequestBody OtpRequest otpRequest) {
        String email = otpRequest.getEmail();
        return emailVerificationService.sendOtp(email);
    }


    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT', 'ROLE_SCHOOL_ADMIN')")
    @PostMapping("/email/verify-otp")
    public SuccessPasswordResponse verifyOtp(@RequestBody OtpVerificationRequest otpVerificationRequest) {
        String email = otpVerificationRequest.getEmail();
        String otp = otpVerificationRequest.getOtp();
        String message = emailVerificationService.verifyOtp(email, otp);
        return new SuccessPasswordResponse(message);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Write_Data')")
    @PostMapping("create-user")
    @ResponseStatus(HttpStatus.CREATED)
    public SuccessResponse addUserByAdmin(
            @Valid
            @RequestBody AddUserByAdminRequestBody addUserByAdminBody) {
        return userService.addUserByAdmin(addUserByAdminBody);
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN') and hasAuthority('Write_Data')")
    @PostMapping("/update-password")
    public ResponseEntity<String> updatePassword(
            @RequestHeader("Authorization") String token,
            @Valid @RequestBody UpdatePasswordRequest request) {

        if (token.startsWith("Bearer ")) {
            token = token.substring(7);
        }
        String message = userService.updatePassword(token, request);
        return ResponseEntity.ok(message);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Read_Data')")
    @GetMapping("/export/excel")
    public void exportUsersToExcel(HttpServletResponse response) throws IOException {
        response.setContentType("application/octet-stream");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
        String currentDateTime = dateFormatter.format(new Date());

        String headerKey = "Content-Disposition";
        String headerValue = ("attachment; filename=file_" + currentDateTime + ".xlsx");
        response.setHeader(headerKey, headerValue);

        List<User> users = userService.getAllUsersForExcelSheet();
        System.out.println("Fetched " + users.size() + " users for export.");
        ExcelExportUtil excelExportUtil = new ExcelExportUtil(users);
        excelExportUtil.export(response);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Write_Data')")
    @PostMapping("/bulk-upload")
    public ResponseEntity<String> uploadUsers(@RequestParam("file") MultipartFile file) {
        try {
            userService.saveUsers(file);
            return ResponseEntity.ok("Users uploaded successfully!");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Failed to process the file. Please try again.");
        }
    }


//    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Read_Data')")
//    @GetMapping("/users-with-roles")
//    public ResponseEntity<List<UserProfileLimitedInfo>> getUsersWithRoles(
//            @RequestParam(required = false) String searchKey) {
//        List<UserProfileLimitedInfo> users = userService.getAllUserAndProfiles(searchKey);
//        return ResponseEntity.ok(users);
//    }

//    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Read_Data')")
//    @GetMapping(value = "/and/profiles")
//    public PageResponse<UserAndProfile> getAllUserAndProfiles(
//            @Positive
//            @RequestParam(required = false, defaultValue = "1") Integer pageNumber,
//            @Positive
//            @RequestParam(required = false, defaultValue = "10") Integer pageSize,
//            @RequestParam(required = false) Role role,
//            @RequestParam(required = false) String searchKey) {
//        return userService.getAllUserAndProfiles(pageNumber, pageSize, searchKey);
//    }

    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Read_Data')")
    @GetMapping(value = "/and/profiles")
    public PageResponse<UserAndProfile> getAllUserAndProfiles(
            @Positive
            @RequestParam(required = false, defaultValue = "1") Integer pageNumber,
            @Positive
            @RequestParam(required = false, defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String searchKey,
            @RequestParam(required = false) Role roleName) {

        return userService.getAllUserAndProfiles(pageNumber, pageSize, searchKey, roleName);
    }

    @GetMapping("/role/{roleName}")
    public ResponseEntity<List<User>> getUsersByRole(@PathVariable Role roleName) {
        List<User> users = userService.getUsersByRole(roleName);
        return ResponseEntity.ok(users);
    }

    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT',  'ROLE_SCHOOL_ADMIN')")
    @PostMapping("/mobile/send-otp")
    public OtpVerificationResponse sendOtp(@RequestBody SendOtpMobileRequest request) {
        return userService.sendOtp(request);
    }
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_STUDENT' , 'ROLE_SCHOOL_ADMIN') and hasAuthority('Write_Data')")
    @PostMapping("/mobile/verify-otp")
    public OtpVerificationResponse verifyOtp(@RequestBody VerifyOtpMobileRequest request) {
        return userService.verifyOtp(request);
    }

    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Read_Data')")
    @GetMapping("/status/{status}")
    public List<User> getUsersByStatus(@PathVariable UserStatus status) {
        return userService.getUsersByStatus(status);
    }


    @PreAuthorize("hasRole('ROLE_ADMIN') and hasAuthority('Read_Data')")
//    @PreAuthorize("hasAuthority('Read_Data')")
    @GetMapping("/timeframe")
    public List<NewlyOnboaredUserAndProfileResponse> getUsersByTimeframe(
            @RequestParam UserStatus status,
            @RequestParam  TimeFrame timeframeCode,
            @RequestParam(required = false) LocalDateTime startTime,
            @RequestParam(required = false) LocalDateTime endTime) {

        if (timeframeCode != null) {
            TimeFrame timeframe = TimeFrame.fromCode(String.valueOf(timeframeCode));
            endTime = LocalDateTime.now();
            startTime = endTime.minus(timeframe.getDuration());
        }

        return userService.getUsersByTimeframe(status,startTime, endTime);
    }

    @PostMapping("/logout")
    public ResponseEntity<String> logout(HttpServletRequest request) {
        final String authHeader = request.getHeader("Authorization");
        final String jwt = authHeader.substring(7);
        if (jwtService.isTokenExpired(jwt)) {
            throw new ExpiredTokenException("Access token is expired");
        }
        String userId = jwtService.extractUserId(jwt);
        tokenCacheService.invalidateTokens(userId);
        return ResponseEntity.ok("Successfully logged out");
    }
    @PostMapping("/refresh-token")
    public LoginResponse refreshAccessToken(HttpServletRequest request) {
        try {
            final String authHeader = request.getHeader("Authorization");

            if (authHeader == null || !authHeader.startsWith("Bearer ")) {
                throw new UnauthorizedException("Authorization header is missing or invalid");
            }
           String refreshToken = authHeader.substring(7);
            return refreshTokenService.refreshAccessToken(refreshToken);
    }
        catch (IllegalArgumentException e) {
           throw new IllegalArgumentException("Invalid refresh token "+e.getMessage());
        } catch (UserNotFoundException e) {
            throw new UserNotFoundException("User not found: " + e.getMessage());
        } catch (Exception e) {
            throw new InternalAuthenticationServiceException("Server error");
        }
    }

}