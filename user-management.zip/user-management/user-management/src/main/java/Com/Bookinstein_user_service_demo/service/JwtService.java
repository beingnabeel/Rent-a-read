package Com.Bookinstein_user_service_demo.service;

import Com.Bookinstein_user_service_demo.entities.Permission;
import Com.Bookinstein_user_service_demo.entities.RoleEntity;
import Com.Bookinstein_user_service_demo.entities.User;
import Com.Bookinstein_user_service_demo.entities.UserRole;
import Com.Bookinstein_user_service_demo.repository.RoleRepository;
import Com.Bookinstein_user_service_demo.repository.UserRoleRepository;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class JwtService {
    @Value("${security.jwt.secret-key}")
    private String secretKey;

    @Value("${security.jwt.expiration-time}")
    private long jwtExpiration;

    @Value("${security.jwt.refresh-token-expiration-time}")
    private long refreshTokenExpiration;

    @Autowired
    private PermissionService permissionService;

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private RoleRepository roleRepository;


    private Key getSignInKey() {
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }


    private String buildToken(Map<String, Object> claims, String subject, long expiration) {
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(getSignInKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public boolean isTokenValid(String token, UserDetails userDetails) {
            final String username = extractClaim(token, Claims::getSubject);
            return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
    }

    public boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = Jwts.parserBuilder()
                .setSigningKey(getSignInKey())
                .build()
                .parseClaimsJws(token)
                .getBody();
        return claimsResolver.apply(claims);
    }

    public String generateResetToken(String email) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("resetPassword", true);
        return buildResetToken(claims, email, jwtExpiration);
    }

    private String buildResetToken(
            Map<String, Object> extraClaims,
            String email,
            long expiration
    ) {
        return Jwts
                .builder()
                .setClaims(extraClaims)
                .setSubject(email)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + expiration))
                .signWith(getSignInKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    public String generateAccessToken(User user) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", user.getId());

        List<UserRole> roles = userRoleRepository.findByUserId(user.getId());
        if (roles.isEmpty()) {
            throw new RuntimeException("No roles found for user");
        }
        Optional<RoleEntity> role= roleRepository.findById(roles.get(0).getRoleId());
        if (!role.isPresent()) {
            throw new RuntimeException("Role not found");
        }
        claims.put("role", role.get().getRoleName());

        List<Permission> permissions = permissionService.getPermissionsByUserId(user.getId());
        claims.put("permissions", permissions.stream()
                .map(Permission::getPermissionName)
                .collect(Collectors.toList()));
        claims.put("FirstName", user.getFirstName());
        claims.put("LastName", user.getLastName());
        claims.put("phone",user.getPhoneNo());
        System.out.println("Generated Access Token Claims: " + claims);
        return buildToken(claims, user.getEmail(), jwtExpiration);
    }

    public String generateRefreshToken(User user) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", user.getId());
        List<UserRole> roles = userRoleRepository.findByUserId(user.getId());
        Optional<RoleEntity> role= roleRepository.findById(roles.get(0).getRoleId());
        claims.put("role", role.get().getRoleName());
        claims.put("firstName", user.getFirstName());
        claims.put("lastName", user.getLastName());
        claims.put("phone",user.getPhoneNo());
        System.out.println("Generated Refresh Token Claims: " + claims);
        return buildToken(claims, user.getEmail(), refreshTokenExpiration);
    }

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    public String extractUserId(String token) {
        return extractClaim(token, claims -> claims.get("userId", String.class));
    }

    public String extractFirstName(String token) {
        return extractClaim(token, claims -> claims.get("firstName", String.class));
    }

    public String extractLastName(String token) {
        return extractClaim(token, claims -> claims.get("lastName", String.class));
    }
    public Object extractClaims(String token, String role) {
        return extractClaim(token, claims -> claims.get(role));
    }
    public long getTokenExpiryTime() {
        return jwtExpiration;
    }


}
